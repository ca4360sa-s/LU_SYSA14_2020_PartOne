/**
 * AWebServiceForCRONUSSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

public interface AWebServiceForCRONUSSoap extends java.rmi.Remote {
    public boolean createEmployee(java.lang.String no_, java.lang.String firstName, java.lang.String lastName, java.lang.String jobTitle, java.lang.String address, java.lang.String city) throws java.rmi.RemoteException;
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[] viewEmployee(java.lang.String no_) throws java.rmi.RemoteException;
    public java.lang.String updateEmployee(java.lang.String no_, java.lang.String firstName, java.lang.String lastName, java.lang.String jobTitle, java.lang.String address, java.lang.String city) throws java.rmi.RemoteException;
    public boolean deleteEmployee(java.lang.String no_) throws java.rmi.RemoteException;
}
