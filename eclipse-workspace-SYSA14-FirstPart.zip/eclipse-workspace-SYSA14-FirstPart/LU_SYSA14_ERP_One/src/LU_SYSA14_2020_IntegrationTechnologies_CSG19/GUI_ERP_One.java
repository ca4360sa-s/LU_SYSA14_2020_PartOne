package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.accessibility.*;
import javax.mail.*;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JRadioButton;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JLayeredPane;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.awt.event.ActionEvent;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class GUI_ERP_One {

	private JFrame frameERPOne;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextField textFieldDENo_;
	private JTextField textFieldUENo_;
	private JTextField textFieldUEFirstName;
	private JTextField textFieldUELastName;
	private JTextField textFieldUEJobTitle;
	private JTextField textFieldUEAddress;
	private JTextField textFieldUECity;
	private JTextField textFieldCECity;
	private JTextField textFieldCEAddress;
	private JTextField textFieldCEJobTitle;
	private JTextField textFieldCELastName;
	private JTextField textFieldCEFirstName;
	private JTextField textFieldCENo_;
	private JTable tableDislpayEmployees;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI_ERP_One window = new GUI_ERP_One();
					window.frameERPOne.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUI_ERP_One() {
		initialize();
	}

	public static JLabel lblCECityNF = new JLabel("Feedback");
	public static JLabel lblCEAddressNF = new JLabel("Feedback");
	public static JLabel lblCEJobTitleNF = new JLabel("Feedback");
	public static JLabel lblCELastNameNF = new JLabel("Feedback");
	public static JLabel lblCEFirstNameNF = new JLabel("Feedback");
	public static JLabel lblCENo_NF = new JLabel("Feedback");
	public static JLabel lblCreateEmployeePF = new JLabel("Feedback");
	public static JLabel lblCreateEmployeeNF = new JLabel("Feedback");
	public static JLabel lblUENo_NF = new JLabel("Feedback");
	public static JLabel lblUpdateEmployeePF = new JLabel("Feedback");
	public static JLabel lblUpdateEmployeeNF = new JLabel("Feedback");
	public static JLabel lblDENo_NF = new JLabel("Feedback");
	public static JLabel lblDeleteEmployeePF = new JLabel("Feedback");
	public static JLabel lblDeleteEmployeeNF = new JLabel("Feedback");
	public static JLabel lblDisplayAllEmployeesNF = new JLabel("Feedback");
	public static JLabel lblDisplayAllEmployeesPF = new JLabel("Feedback");

	/**
	 * Initialize the contents of the frame.
	 */
	
	
	private void initialize() {
		frameERPOne = new JFrame();
		frameERPOne.setTitle("ERP-system Uppgift 1");
		frameERPOne.setBounds(100, 100, 900, 600);
		frameERPOne.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameERPOne.getContentPane().setLayout(null);
		AWebServiceForCRONUSSoapProxy proxy = new AWebServiceForCRONUSSoapProxy(); 
		
		JLayeredPane layeredPaneCreateEmployee = new JLayeredPane();
		layeredPaneCreateEmployee.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "L\u00E4gg till anst\u00E4lld", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		layeredPaneCreateEmployee.setBounds(29, 134, 350, 394);
		frameERPOne.getContentPane().add(layeredPaneCreateEmployee);
		layeredPaneCreateEmployee.setLayout(null);
		
		JLayeredPane layeredPaneUpdateEmployee = new JLayeredPane();
		layeredPaneUpdateEmployee.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Uppdatera anst\u00E4lld", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		layeredPaneUpdateEmployee.setBounds(29, 134, 350, 394);
		frameERPOne.getContentPane().add(layeredPaneUpdateEmployee);
		layeredPaneUpdateEmployee.setLayout(null);
		
		JLayeredPane layeredPaneDeleteEmployee = new JLayeredPane();
		layeredPaneDeleteEmployee.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Radera anst\u00E4lld", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		layeredPaneDeleteEmployee.setBounds(29, 134, 350, 123);
		frameERPOne.getContentPane().add(layeredPaneDeleteEmployee);
		layeredPaneDeleteEmployee.setLayout(null);
		
		JScrollPane scrollPaneERPOne = new JScrollPane();
		scrollPaneERPOne.setBounds(389, 137, 467, 394);
		frameERPOne.getContentPane().add(scrollPaneERPOne);
		
		tableDislpayEmployees = new JTable();
		scrollPaneERPOne.setViewportView(tableDislpayEmployees);
			
		//-----------------------------------------------------------------------------------
		
		//JLabel lblCECityNF = new JLabel("Feedback");
		lblCECityNF.setForeground(new Color(204, 51, 0));
		lblCECityNF.setBounds(76, 284, 264, 13);
		layeredPaneCreateEmployee.add(lblCECityNF);
		lblCECityNF.setVisible(false);
		
		//JLabel lblCEAddressNF = new JLabel("Feedback");
		lblCEAddressNF.setForeground(new Color(204, 51, 0));
		lblCEAddressNF.setBounds(76, 241, 264, 13);
		layeredPaneCreateEmployee.add(lblCEAddressNF);
		lblCEAddressNF.setVisible(false);
		
		//JLabel lblCEJobTitleNF = new JLabel("Feedback");
		lblCEJobTitleNF.setForeground(new Color(204, 51, 0));
		lblCEJobTitleNF.setBounds(76, 198, 264, 13);
		layeredPaneCreateEmployee.add(lblCEJobTitleNF);
		lblCEJobTitleNF.setVisible(false);
		
		//JLabel lblCELastNameNF = new JLabel("Feedback");
		lblCELastNameNF.setForeground(new Color(204, 51, 0));
		lblCELastNameNF.setBounds(76, 155, 264, 13);
		layeredPaneCreateEmployee.add(lblCELastNameNF);
		lblCELastNameNF.setVisible(false);
		
		//JLabel lblCEFirstNameNF = new JLabel("Feedback");
		lblCEFirstNameNF.setForeground(new Color(204, 51, 0));
		lblCEFirstNameNF.setBounds(76, 112, 264, 13);
		layeredPaneCreateEmployee.add(lblCEFirstNameNF);
		lblCEFirstNameNF.setVisible(false);	
		
		//JLabel lblCENo_NF = new JLabel("Feedback");
		lblCENo_NF.setForeground(new Color(204, 51, 0));
		lblCENo_NF.setBounds(76, 69, 264, 13);
		layeredPaneCreateEmployee.add(lblCENo_NF);
		lblCENo_NF.setVisible(false);
		
		//JLabel lblCreateEmployeePF = new JLabel("Feedback");
		lblCreateEmployeePF.setForeground(new Color(0, 153, 0));
		lblCreateEmployeePF.setBounds(10, 329, 330, 13);
		layeredPaneCreateEmployee.add(lblCreateEmployeePF);
		lblCreateEmployeePF.setVisible(false);
		
		//JLabel lblCreateEmployeeNF = new JLabel("Feedback");
		lblCreateEmployeeNF.setForeground(new Color(204, 51, 0));
		lblCreateEmployeeNF.setBounds(10, 329, 330, 13);
		layeredPaneCreateEmployee.add(lblCreateEmployeeNF);
		layeredPaneCreateEmployee.setVisible(true);
		lblCreateEmployeeNF.setVisible(false);
		
		//JLabel lblUENo_NF = new JLabel("Feedback");
		lblUENo_NF.setForeground(new Color(204, 51, 0));
		lblUENo_NF.setBounds(79, 45, 261, 13);
		layeredPaneUpdateEmployee.add(lblUENo_NF);
		lblUENo_NF.setVisible(false);
		
		//JLabel lblUpdateEmployeePF = new JLabel("Feedback");
		lblUpdateEmployeePF.setForeground(new Color(0, 153, 0));
		lblUpdateEmployeePF.setBounds(10, 331, 330, 13);
		layeredPaneUpdateEmployee.add(lblUpdateEmployeePF);
		lblUpdateEmployeePF.setVisible(false);
		
		//JLabel lblUpdateEmployeeNF = new JLabel("Feedback");
		lblUpdateEmployeeNF.setForeground(new Color(204, 51, 0));
		lblUpdateEmployeeNF.setBounds(10, 331, 380, 13);
		layeredPaneUpdateEmployee.add(lblUpdateEmployeeNF);
		layeredPaneUpdateEmployee.setVisible(false);
		lblUpdateEmployeeNF.setVisible(false);
		
		//JLabel lblDENo_NF = new JLabel("Feedback");
		lblDENo_NF.setForeground(new Color(204, 51, 0));
		lblDENo_NF.setBounds(34, 28, 306, 13);
		layeredPaneDeleteEmployee.add(lblDENo_NF);
		lblDENo_NF.setVisible(false);
		
		//JLabel lblDeleteEmployeePF = new JLabel("Feedback");
		lblDeleteEmployeePF.setForeground(new Color(0, 153, 0));
		lblDeleteEmployeePF.setBounds(10, 73, 330, 13);
		layeredPaneDeleteEmployee.add(lblDeleteEmployeePF);
		lblDeleteEmployeePF.setVisible(false);
		
		//JLabel lblDeleteEmployeeNF = new JLabel("Feedback");
		lblDeleteEmployeeNF.setForeground(new Color(204, 51, 0));
		lblDeleteEmployeeNF.setBounds(10, 73, 242, 13);
		layeredPaneDeleteEmployee.add(lblDeleteEmployeeNF);
		layeredPaneDeleteEmployee.setVisible(false);
		lblDeleteEmployeeNF.setVisible(false);
		
		//JLabel lblDisplayAllEmployeesNF = new JLabel("Feedback");
		lblDisplayAllEmployeesNF.setForeground(new Color(204, 51, 0));
		lblDisplayAllEmployeesNF.setBounds(544, 93, 312, 13);
		frameERPOne.getContentPane().add(lblDisplayAllEmployeesNF);
		lblDisplayAllEmployeesNF.setVisible(false);
		
		//JLabel lblDisplayAllEmployeesPF = new JLabel("Feedback");
		lblDisplayAllEmployeesPF.setForeground(new Color(0, 153, 0));
		lblDisplayAllEmployeesPF.setBounds(544, 93, 312, 13);
		frameERPOne.getContentPane().add(lblDisplayAllEmployeesPF);
		lblDisplayAllEmployeesPF.setVisible(false);
		

		
		//-----------------------------------------------------------------------------------
	
		JLabel lblCECity = new JLabel("Stad");
		lblCECity.setBounds(10, 284, 65, 13);
		layeredPaneCreateEmployee.add(lblCECity);
		
		JLabel lblCEAddress = new JLabel("Adress");
		lblCEAddress.setBounds(10, 241, 65, 13);
		layeredPaneCreateEmployee.add(lblCEAddress);
		
		JLabel lblCEJobTitle = new JLabel("Jobbtitel");
		lblCEJobTitle.setBounds(10, 198, 65, 13);
		layeredPaneCreateEmployee.add(lblCEJobTitle);		
		
		JLabel lblCELastName = new JLabel("Efternamn");
		lblCELastName.setBounds(10, 155, 65, 13);
		layeredPaneCreateEmployee.add(lblCELastName);
		
		JLabel lblCEFirstName = new JLabel("F\u00F6rnamn");
		lblCEFirstName.setBounds(10, 112, 56, 13);
		layeredPaneCreateEmployee.add(lblCEFirstName);

		JLabel lblCENo_ = new JLabel("No_");
		lblCENo_.setBounds(10, 69, 46, 13);
		layeredPaneCreateEmployee.add(lblCENo_);
		
		JLabel lblCEHeadInfo = new JLabel("Ange den anst\u00E4lldes information");
		lblCEHeadInfo.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblCEHeadInfo.setBounds(10, 46, 176, 13);
		layeredPaneCreateEmployee.add(lblCEHeadInfo);
		
		JLabel lblUENo_ = new JLabel("No_");
		lblUENo_.setBounds(10, 45, 46, 13);
		layeredPaneUpdateEmployee.add(lblUENo_);
				
		JLabel lblUEInfoOne = new JLabel("1. Ange den anst\u00E4lldes No_");
		lblUEInfoOne.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblUEInfoOne.setBounds(10, 26, 142, 13);
		layeredPaneUpdateEmployee.add(lblUEInfoOne);
		
		JLabel lblUEFirstName = new JLabel("F\u00F6rnamn");
		lblUEFirstName.setBounds(10, 115, 96, 13);
		layeredPaneUpdateEmployee.add(lblUEFirstName);

		JLabel lblUELastName = new JLabel("Efternamn");
		lblUELastName.setBounds(10, 158, 96, 13);
		layeredPaneUpdateEmployee.add(lblUELastName);		
		
		JLabel lblUEJobTitle = new JLabel("Jobbtitel");
		lblUEJobTitle.setBounds(10, 201, 96, 13);
		layeredPaneUpdateEmployee.add(lblUEJobTitle);			
		
		JLabel lblUEAddress = new JLabel("Adress");
		lblUEAddress.setBounds(10, 244, 96, 13);
		layeredPaneUpdateEmployee.add(lblUEAddress);
		
		JLabel lblUECity = new JLabel("Stad");
		lblUECity.setBounds(10, 287, 96, 13);
		layeredPaneUpdateEmployee.add(lblUECity);
		
		JLabel lblUEInfoTwo = new JLabel("2. Ange den information som skall uppdateras");
		lblUEInfoTwo.setFont(new Font("Tahoma", Font.BOLD, 10));
		lblUEInfoTwo.setBounds(10, 98, 245, 13);
		layeredPaneUpdateEmployee.add(lblUEInfoTwo);
		
		JLabel lblDENo_ = new JLabel("No_");
		lblDENo_.setBounds(10, 28, 46, 13);
		layeredPaneDeleteEmployee.add(lblDENo_);
					
		JLabel lblHeadInfo = new JLabel("CRONUS Employees - Klient 2");
		lblHeadInfo.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblHeadInfo.setBounds(244, 10, 276, 21);
		frameERPOne.getContentPane().add(lblHeadInfo);	
		
		//-----------------------------------------------------------------------------------

		textFieldCECity = new JTextField();
		textFieldCECity.setColumns(10);
		textFieldCECity.setBounds(10, 298, 96, 19);
		layeredPaneCreateEmployee.add(textFieldCECity);
		
		textFieldCEAddress = new JTextField();
		textFieldCEAddress.setColumns(10);
		textFieldCEAddress.setBounds(10, 255, 96, 19);
		layeredPaneCreateEmployee.add(textFieldCEAddress);
		
		textFieldCEJobTitle = new JTextField();
		textFieldCEJobTitle.setColumns(10);
		textFieldCEJobTitle.setBounds(10, 212, 96, 19);
		layeredPaneCreateEmployee.add(textFieldCEJobTitle);	
		
		textFieldCELastName = new JTextField();
		textFieldCELastName.setColumns(10);
		textFieldCELastName.setBounds(10, 169, 96, 19);
		layeredPaneCreateEmployee.add(textFieldCELastName);		
		
		textFieldCEFirstName = new JTextField();
		textFieldCEFirstName.setColumns(10);
		textFieldCEFirstName.setBounds(10, 126, 96, 19);
		layeredPaneCreateEmployee.add(textFieldCEFirstName);
			
		textFieldCENo_ = new JTextField();
		textFieldCENo_.setColumns(10);
		textFieldCENo_.setBounds(10, 83, 96, 19);
		layeredPaneCreateEmployee.add(textFieldCENo_);
			
		textFieldUENo_ = new JTextField();
		textFieldUENo_.setColumns(10);
		textFieldUENo_.setBounds(10, 59, 96, 19);
		layeredPaneUpdateEmployee.add(textFieldUENo_);
			
		textFieldUEFirstName = new JTextField();
		textFieldUEFirstName.setColumns(10);
		textFieldUEFirstName.setBounds(10, 129, 96, 19);
		layeredPaneUpdateEmployee.add(textFieldUEFirstName);
		
		textFieldUELastName = new JTextField();
		textFieldUELastName.setColumns(10);
		textFieldUELastName.setBounds(10, 172, 96, 19);
		layeredPaneUpdateEmployee.add(textFieldUELastName);
		
		textFieldUEJobTitle = new JTextField();
		textFieldUEJobTitle.setColumns(10);
		textFieldUEJobTitle.setBounds(10, 215, 96, 19);
		layeredPaneUpdateEmployee.add(textFieldUEJobTitle);
		
		textFieldUEAddress = new JTextField();
		textFieldUEAddress.setColumns(10);
		textFieldUEAddress.setBounds(10, 258, 96, 19);
		layeredPaneUpdateEmployee.add(textFieldUEAddress);
		
		textFieldUECity = new JTextField();
		textFieldUECity.setColumns(10);
		textFieldUECity.setBounds(10, 301, 96, 19);
		layeredPaneUpdateEmployee.add(textFieldUECity);	
		
		textFieldDENo_ = new JTextField();
		textFieldDENo_.setBounds(10, 42, 96, 19);
		layeredPaneDeleteEmployee.add(textFieldDENo_);
		textFieldDENo_.setColumns(10);
		
		//-----------------------------------------------------------------------------------
		
		JRadioButton rdbtnCreateEmployee = new JRadioButton("L\u00E4gg till anst\u00E4lld");
		buttonGroup.add(rdbtnCreateEmployee);
		rdbtnCreateEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				layeredPaneCreateEmployee.setVisible(true);
				layeredPaneUpdateEmployee.setVisible(false);
				layeredPaneDeleteEmployee.setVisible(false);
				
			}
		});
		rdbtnCreateEmployee.setSelected(true);
		rdbtnCreateEmployee.setBounds(29, 40, 137, 21);
		frameERPOne.getContentPane().add(rdbtnCreateEmployee);
		
		JRadioButton rdbtnUpdateEmployee = new JRadioButton("Uppdatera anst\u00E4lld");
		buttonGroup.add(rdbtnUpdateEmployee);
		rdbtnUpdateEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				layeredPaneCreateEmployee.setVisible(false);
				layeredPaneUpdateEmployee.setVisible(true);
				layeredPaneDeleteEmployee.setVisible(false);
			}
		});
		rdbtnUpdateEmployee.setBounds(29, 63, 153, 21);
		frameERPOne.getContentPane().add(rdbtnUpdateEmployee);
		
		JRadioButton rdbtnDeleteEmployee = new JRadioButton("Radera anst\u00E4lld");
		buttonGroup.add(rdbtnDeleteEmployee);
		rdbtnDeleteEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				layeredPaneCreateEmployee.setVisible(false);
				layeredPaneUpdateEmployee.setVisible(false);
				layeredPaneDeleteEmployee.setVisible(true);
			}
		});
		rdbtnDeleteEmployee.setBounds(29, 85, 153, 21);
		frameERPOne.getContentPane().add(rdbtnDeleteEmployee);
		
		//-----------------------------------------------------------------------------------

		JButton btnUpdateEmployee = new JButton("Uppdatera");
		btnUpdateEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ClearAllFeedback();
				String no_ = textFieldUENo_.getText(); 
				String firstName = textFieldUEFirstName.getText(); 
				String lastName = textFieldUELastName.getText(); 
				String jobTitle = textFieldUEJobTitle.getText();
				String address = textFieldUEAddress.getText();
				String city = textFieldUECity.getText();
				if(no_.length() == 0) {
					lblUENo_NF.setText("Ange no_");
					lblUENo_NF.setVisible(true);
				}
				else {
					try {
						String resultOfUpdate = proxy.updateEmployee(no_, firstName, lastName, jobTitle, address, city);
						if(resultOfUpdate.length() == 0) {
							lblUpdateEmployeeNF.setText("Aktuellt no_ finns ej");
							lblUpdateEmployeeNF.setVisible(true);
						}
						else {
							lblUpdateEmployeePF.setText(resultOfUpdate);
							lblUpdateEmployeePF.setVisible(true);
							textFieldUENo_.setText("");
							textFieldUEFirstName.setText("");
							textFieldUELastName.setText("");
							textFieldUEJobTitle.setText("");
							textFieldUEAddress.setText("");
							textFieldUECity.setText("");
						}
					} catch (RemoteException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		btnUpdateEmployee.setFont(new Font("Tahoma", Font.BOLD, 10));
		btnUpdateEmployee.setBounds(10, 344, 96, 21);
		layeredPaneUpdateEmployee.add(btnUpdateEmployee);
		
		JButton btnDeleteEmployee = new JButton("Radera");
		btnDeleteEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ClearAllFeedback();
				String no_ = textFieldDENo_.getText(); 
				if(no_.length() == 0) {
					lblDENo_NF.setText("Ange No_");
					lblDENo_NF.setVisible(true);
				}
				else {
					try {
						if(!proxy.deleteEmployee(no_)) {
							lblDeleteEmployeeNF.setText("Aktuellt no_ finns ej");
							lblDeleteEmployeeNF.setVisible(true);
						}
						else {
							lblDeleteEmployeePF.setText("Den anst�llde har raderats");
							lblDeleteEmployeePF.setVisible(true);
							textFieldDENo_.setText("");
						}
					} catch (RemoteException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
			}
		});
		btnDeleteEmployee.setFont(new Font("Tahoma", Font.BOLD, 10));
		btnDeleteEmployee.setBounds(10, 86, 96, 21);
		layeredPaneDeleteEmployee.add(btnDeleteEmployee);
		
		JButton btnCreateEmployee = new JButton("L\u00E4gg till");
		btnCreateEmployee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ClearAllFeedback(); 
				String no_ = textFieldCENo_.getText(); 
				String firstName = textFieldCEFirstName.getText(); 
				String lastName = textFieldCELastName.getText(); 
				String jobTitle = textFieldCEJobTitle.getText();
				String address = textFieldCEAddress.getText();
				String city = textFieldCECity.getText();
				boolean condition = true; 
				if(no_.length() == 0) {
					lblCENo_NF.setText("Ange no_");
					lblCENo_NF.setVisible(true);
					condition = false; 
				}
				if(firstName.length() == 0) {
					lblCEFirstNameNF.setText("Ange f�rnamn");
					lblCEFirstNameNF.setVisible(true);
					condition = false; 
				}
				if(lastName.length() == 0) {
					lblCELastNameNF.setText("Ange efternamn");
					lblCELastNameNF.setVisible(true);
					condition = false; 
				}
				if(jobTitle.length() == 0) {
					lblCEJobTitleNF.setText("Ange jobbtitel");
					lblCEJobTitleNF.setVisible(true);
					condition = false; 
				}
				if(address.length() == 0) {
					lblCEAddressNF.setText("Ange adress");
					lblCEAddressNF.setVisible(true);	
					condition = false; 
				}
				if(city.length() == 0) {					
					lblCECityNF.setText("Ange stad");
					lblCECityNF.setVisible(true);
					condition = false; 
				}
				if(condition) {
					try {
						boolean result = proxy.createEmployee(no_, firstName, lastName, jobTitle, address, city);
						if(!result) {
							lblCreateEmployeeNF.setText("Den anst�llde finns redan");
							lblCreateEmployeeNF.setVisible(true);
						}
						else {
							lblCreateEmployeePF.setText("Den anst�llde har lagts till");
							lblCreateEmployeePF.setVisible(true);
							textFieldCENo_.setText("");
							textFieldCEFirstName.setText("");
							textFieldCELastName.setText("");
							textFieldCEJobTitle.setText("");
							textFieldCEAddress.setText("");
							textFieldCECity.setText("");
							
						}
					} catch (RemoteException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
				
			}
		});
		btnCreateEmployee.setFont(new Font("Tahoma", Font.BOLD, 10));
		btnCreateEmployee.setBounds(10, 341, 96, 21);
		layeredPaneCreateEmployee.add(btnCreateEmployee);
		
		JButton btnDisplayAllEmployees = new JButton("Visa alla anst\u00E4llda");
		btnDisplayAllEmployees.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ClearAllFeedback();
				String aEmptyString = "";
				try {
					if(proxy.viewEmployee(aEmptyString).length == 0) {
						lblDisplayAllEmployeesNF.setText("Finns inga anst�llda");
						lblDisplayAllEmployeesNF.setVisible(true);
					}
					else {
						DefaultTableModel model = new DefaultTableModel(); 
						model.addColumn("No_");
						model.addColumn("F�rnamn");
						model.addColumn("Efternamn");
						model.addColumn("Jobbtitel");
						model.addColumn("Adress");
						model.addColumn("Stad");
						for (Employee temp : proxy.viewEmployee(aEmptyString)) {
							model.addRow(new String[] {temp.getNo_(), temp.getFirstName(), temp.getLastName(), temp.getJobTitle(),temp.getAddress(), temp.getCity()});
							tableDislpayEmployees.setModel(model);
							lblDisplayAllEmployeesPF.setText("Resultatet visas");
							lblDisplayAllEmployeesPF.setVisible(true);
						}

					}
				} catch (RemoteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnDisplayAllEmployees.setFont(new Font("Tahoma", Font.BOLD, 10));
		btnDisplayAllEmployees.setBounds(544, 106, 153, 21);
		frameERPOne.getContentPane().add(btnDisplayAllEmployees);
	
	}
	private void ClearAllFeedback() {
	
		lblCECityNF.setVisible(false);
		lblCEAddressNF.setVisible(false);
		lblCEJobTitleNF.setVisible(false);
		lblCELastNameNF.setVisible(false);
		lblCEFirstNameNF.setVisible(false);
		lblCENo_NF.setVisible(false);
		lblCreateEmployeePF.setVisible(false);
		lblCreateEmployeeNF.setVisible(false);
		lblUENo_NF.setVisible(false);
		lblUpdateEmployeePF.setVisible(false);
		lblUpdateEmployeeNF.setVisible(false);
		lblDENo_NF.setVisible(false);
		lblDeleteEmployeePF.setVisible(false);
		lblDeleteEmployeeNF.setVisible(false);
		lblDisplayAllEmployeesNF.setVisible(false);
		lblDisplayAllEmployeesPF.setVisible(false);
	}

}
