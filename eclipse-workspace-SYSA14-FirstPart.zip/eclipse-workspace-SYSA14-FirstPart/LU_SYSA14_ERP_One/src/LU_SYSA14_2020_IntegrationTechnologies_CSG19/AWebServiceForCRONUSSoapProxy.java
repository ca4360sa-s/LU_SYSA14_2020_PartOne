package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

public class AWebServiceForCRONUSSoapProxy implements LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceForCRONUSSoap {
  private String _endpoint = null;
  private LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceForCRONUSSoap aWebServiceForCRONUSSoap = null;
  
  public AWebServiceForCRONUSSoapProxy() {
    _initAWebServiceForCRONUSSoapProxy();
  }
  
  public AWebServiceForCRONUSSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initAWebServiceForCRONUSSoapProxy();
  }
  
  private void _initAWebServiceForCRONUSSoapProxy() {
    try {
      aWebServiceForCRONUSSoap = (new LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceForCRONUSLocator()).getAWebServiceForCRONUSSoap();
      if (aWebServiceForCRONUSSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)aWebServiceForCRONUSSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)aWebServiceForCRONUSSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (aWebServiceForCRONUSSoap != null)
      ((javax.xml.rpc.Stub)aWebServiceForCRONUSSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceForCRONUSSoap getAWebServiceForCRONUSSoap() {
    if (aWebServiceForCRONUSSoap == null)
      _initAWebServiceForCRONUSSoapProxy();
    return aWebServiceForCRONUSSoap;
  }
  
  public boolean createEmployee(java.lang.String no_, java.lang.String firstName, java.lang.String lastName, java.lang.String jobTitle, java.lang.String address, java.lang.String city) throws java.rmi.RemoteException{
    if (aWebServiceForCRONUSSoap == null)
      _initAWebServiceForCRONUSSoapProxy();
    return aWebServiceForCRONUSSoap.createEmployee(no_, firstName, lastName, jobTitle, address, city);
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[] viewEmployee(java.lang.String no_) throws java.rmi.RemoteException{
    if (aWebServiceForCRONUSSoap == null)
      _initAWebServiceForCRONUSSoapProxy();
    return aWebServiceForCRONUSSoap.viewEmployee(no_);
  }
  
  public java.lang.String updateEmployee(java.lang.String no_, java.lang.String firstName, java.lang.String lastName, java.lang.String jobTitle, java.lang.String address, java.lang.String city) throws java.rmi.RemoteException{
    if (aWebServiceForCRONUSSoap == null)
      _initAWebServiceForCRONUSSoapProxy();
    return aWebServiceForCRONUSSoap.updateEmployee(no_, firstName, lastName, jobTitle, address, city);
  }
  
  public boolean deleteEmployee(java.lang.String no_) throws java.rmi.RemoteException{
    if (aWebServiceForCRONUSSoap == null)
      _initAWebServiceForCRONUSSoapProxy();
    return aWebServiceForCRONUSSoap.deleteEmployee(no_);
  }
  
  
}