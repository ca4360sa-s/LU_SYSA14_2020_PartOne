/**
 * AWebServiceToHandleFiles.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

public interface AWebServiceToHandleFiles extends javax.xml.rpc.Service {
    public java.lang.String getAWebServiceToHandleFilesSoapAddress();

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleFilesSoap getAWebServiceToHandleFilesSoap() throws javax.xml.rpc.ServiceException;

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleFilesSoap getAWebServiceToHandleFilesSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
