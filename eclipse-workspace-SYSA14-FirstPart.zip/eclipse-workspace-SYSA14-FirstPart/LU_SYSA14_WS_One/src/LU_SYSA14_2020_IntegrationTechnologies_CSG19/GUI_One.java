package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.awt.event.ActionEvent;

public class GUI_One {

	private JFrame frmWebServiceUppgift;
	private JTextArea textAreaViewFileContent;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI_One window = new GUI_One();
					window.frmWebServiceUppgift.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUI_One() {
		initialize();
	}

	
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmWebServiceUppgift = new JFrame();
		frmWebServiceUppgift.setTitle("Web Service Uppgift 1");
		frmWebServiceUppgift.setBounds(100, 100, 700, 600);
		frmWebServiceUppgift.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmWebServiceUppgift.getContentPane().setLayout(null);
		Hashtable<String, String> tableOfNamesAndAddresses = new Hashtable<String, String>();  
		AWebServiceToHandleFilesSoapProxy proxy = new AWebServiceToHandleFilesSoapProxy(); 

		JLabel lblHeadInfo = new JLabel("Visningsalternativ f\u00F6r fil - Klient 3");
		lblHeadInfo.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblHeadInfo.setBounds(196, 43, 297, 39);
		frmWebServiceUppgift.getContentPane().add(lblHeadInfo);
		
		JPanel panelViewSelectedFile = new JPanel();
		panelViewSelectedFile.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Val av fil", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLACK));
		panelViewSelectedFile.setBounds(77, 268, 283, 171);
		frmWebServiceUppgift.getContentPane().add(panelViewSelectedFile);
		panelViewSelectedFile.setLayout(null);
		panelViewSelectedFile.setVisible(false);
		
		JComboBox comboBoxFileAlternatives = new JComboBox();
		comboBoxFileAlternatives.setBounds(25, 70, 228, 21);
		panelViewSelectedFile.add(comboBoxFileAlternatives);
		
		JLabel lblViewSelectedFilePF = new JLabel("Feedback");
		lblViewSelectedFilePF.setForeground(new Color(0, 153, 0));
		lblViewSelectedFilePF.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblViewSelectedFilePF.setBounds(25, 49, 248, 19);
		panelViewSelectedFile.add(lblViewSelectedFilePF);
		lblViewSelectedFilePF.setVisible(false);
		
		JLabel lblViewSelectedFileNF = new JLabel("Feedback");
		lblViewSelectedFileNF.setForeground(new Color(255, 51, 51));
		lblViewSelectedFileNF.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblViewSelectedFileNF.setBounds(25, 49, 210, 19);
		panelViewSelectedFile.add(lblViewSelectedFileNF);		
		lblViewSelectedFileNF.setVisible(false);
		
		textAreaViewFileContent = new JTextArea();
		textAreaViewFileContent.setEditable(false);
		textAreaViewFileContent.setBounds(387, 159, 243, 280);
		frmWebServiceUppgift.getContentPane().add(textAreaViewFileContent);
		textAreaViewFileContent.setLineWrap(true);
		textAreaViewFileContent.setWrapStyleWord(true);
		
		JLabel lblRetriveAllFilesPF = new JLabel("Feedback");
		lblRetriveAllFilesPF.setForeground(new Color(0, 153, 0));
		lblRetriveAllFilesPF.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblRetriveAllFilesPF.setBounds(156, 175, 221, 19);
		frmWebServiceUppgift.getContentPane().add(lblRetriveAllFilesPF);
		lblRetriveAllFilesPF.setVisible(false);
		
		JLabel lblRetriveAllFilesNF = new JLabel("Feedback");
		lblRetriveAllFilesNF.setForeground(new Color(255, 51, 51));
		lblRetriveAllFilesNF.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblRetriveAllFilesNF.setBounds(156, 175, 226, 19);
		frmWebServiceUppgift.getContentPane().add(lblRetriveAllFilesNF);
		lblRetriveAllFilesNF.setVisible(false);
		
		//---------------------------------------------------------------------
		
		JButton btnRetrieveAllFiles = new JButton("H\u00E4mta alla filer");
		btnRetrieveAllFiles.addActionListener(new ActionListener() {			
			public void actionPerformed(ActionEvent e) {
				lblRetriveAllFilesNF.setVisible(false);
				lblRetriveAllFilesPF.setVisible(false);
				lblViewSelectedFileNF.setVisible(false); 
				lblViewSelectedFilePF.setVisible(false); 
				panelViewSelectedFile.setVisible(true);
				tableOfNamesAndAddresses.clear();
				comboBoxFileAlternatives.removeAllItems();
				textAreaViewFileContent.setText(null);
				try {
					String[] nameOfFiles = proxy.findAllFileNamesInTheDirectory(); 
					if(nameOfFiles.length == 0) {
						lblRetriveAllFilesNF.setText("Finns inga filer i mappen"); 
						lblRetriveAllFilesNF.setVisible(true);
					}
					else {
						for (String fileAddress : nameOfFiles) {						
							int i = fileAddress.length(); 
							String fileName = fileAddress.substring(119, i-4);
							comboBoxFileAlternatives.addItem(fileName);
							tableOfNamesAndAddresses.put(fileName, fileAddress);
							lblRetriveAllFilesPF.setText("Filerna har h�mtats"); 
							lblRetriveAllFilesPF.setVisible(true);
							}					
						}
					} catch (RemoteException ex) {
					// TODO Auto-generated catch block
					ex.printStackTrace();
				}
			}
		});

		btnRetrieveAllFiles.setFont(new Font("Tahoma", Font.BOLD, 10));
		btnRetrieveAllFiles.setBounds(156, 194, 130, 29);
		frmWebServiceUppgift.getContentPane().add(btnRetrieveAllFiles);
		
		JButton btnViewSelectedFile = new JButton("Visa");
		btnViewSelectedFile.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lblRetriveAllFilesNF.setVisible(false);
				lblRetriveAllFilesPF.setVisible(false);
				lblViewSelectedFileNF.setVisible(false); 
				lblViewSelectedFilePF.setVisible(false); 
				textAreaViewFileContent.setText(null);
				if(comboBoxFileAlternatives.getItemCount() == 0) {
					lblViewSelectedFileNF.setText("Inga filalternativ");
					lblViewSelectedFileNF.setVisible(true);
				} 
				else {
					String address = tableOfNamesAndAddresses.get(comboBoxFileAlternatives.getSelectedItem().toString()); 
					
					try {
						String result = proxy.displayAFile(address);
						if(result.length() == 0) {
							lblViewSelectedFileNF.setText("Filen inneh�ller ingen text");
							lblViewSelectedFileNF.setVisible(true);
						}
						else {
							textAreaViewFileContent.append(result);
							lblViewSelectedFilePF.setText("Filen visas");
							lblViewSelectedFilePF.setVisible(true);
						}
					} catch (RemoteException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
				
			}
		});
		btnViewSelectedFile.setFont(new Font("Tahoma", Font.BOLD, 10));
		btnViewSelectedFile.setBounds(86, 117, 130, 29);
		panelViewSelectedFile.add(btnViewSelectedFile);
	}
	

}
