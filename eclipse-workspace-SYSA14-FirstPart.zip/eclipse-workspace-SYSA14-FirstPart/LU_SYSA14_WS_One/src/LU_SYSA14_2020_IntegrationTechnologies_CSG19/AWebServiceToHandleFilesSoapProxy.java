package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

public class AWebServiceToHandleFilesSoapProxy implements LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleFilesSoap {
  private String _endpoint = null;
  private LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleFilesSoap aWebServiceToHandleFilesSoap = null;
  
  public AWebServiceToHandleFilesSoapProxy() {
    _initAWebServiceToHandleFilesSoapProxy();
  }
  
  public AWebServiceToHandleFilesSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initAWebServiceToHandleFilesSoapProxy();
  }
  
  private void _initAWebServiceToHandleFilesSoapProxy() {
    try {
      aWebServiceToHandleFilesSoap = (new LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleFilesLocator()).getAWebServiceToHandleFilesSoap();
      if (aWebServiceToHandleFilesSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)aWebServiceToHandleFilesSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)aWebServiceToHandleFilesSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (aWebServiceToHandleFilesSoap != null)
      ((javax.xml.rpc.Stub)aWebServiceToHandleFilesSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleFilesSoap getAWebServiceToHandleFilesSoap() {
    if (aWebServiceToHandleFilesSoap == null)
      _initAWebServiceToHandleFilesSoapProxy();
    return aWebServiceToHandleFilesSoap;
  }
  
  public java.lang.String displayAFile(java.lang.String fileName) throws java.rmi.RemoteException{
    if (aWebServiceToHandleFilesSoap == null)
      _initAWebServiceToHandleFilesSoapProxy();
    return aWebServiceToHandleFilesSoap.displayAFile(fileName);
  }
  
  public java.lang.String[] findAllFileNamesInTheDirectory() throws java.rmi.RemoteException{
    if (aWebServiceToHandleFilesSoap == null)
      _initAWebServiceToHandleFilesSoapProxy();
    return aWebServiceToHandleFilesSoap.findAllFileNamesInTheDirectory();
  }
  
  
}