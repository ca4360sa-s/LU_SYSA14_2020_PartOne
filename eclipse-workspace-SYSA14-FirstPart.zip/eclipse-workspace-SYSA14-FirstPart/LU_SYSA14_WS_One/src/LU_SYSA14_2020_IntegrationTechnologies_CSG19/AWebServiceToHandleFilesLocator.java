/**
 * AWebServiceToHandleFilesLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

public class AWebServiceToHandleFilesLocator extends org.apache.axis.client.Service implements LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleFiles {

    public AWebServiceToHandleFilesLocator() {
    }


    public AWebServiceToHandleFilesLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public AWebServiceToHandleFilesLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for AWebServiceToHandleFilesSoap
    private java.lang.String AWebServiceToHandleFilesSoap_address = "https://localhost:44327/AWebServiceToHandleFiles.asmx";

    public java.lang.String getAWebServiceToHandleFilesSoapAddress() {
        return AWebServiceToHandleFilesSoap_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String AWebServiceToHandleFilesSoapWSDDServiceName = "AWebServiceToHandleFilesSoap";

    public java.lang.String getAWebServiceToHandleFilesSoapWSDDServiceName() {
        return AWebServiceToHandleFilesSoapWSDDServiceName;
    }

    public void setAWebServiceToHandleFilesSoapWSDDServiceName(java.lang.String name) {
        AWebServiceToHandleFilesSoapWSDDServiceName = name;
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleFilesSoap getAWebServiceToHandleFilesSoap() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(AWebServiceToHandleFilesSoap_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getAWebServiceToHandleFilesSoap(endpoint);
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleFilesSoap getAWebServiceToHandleFilesSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleFilesSoapStub _stub = new LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleFilesSoapStub(portAddress, this);
            _stub.setPortName(getAWebServiceToHandleFilesSoapWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setAWebServiceToHandleFilesSoapEndpointAddress(java.lang.String address) {
        AWebServiceToHandleFilesSoap_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleFilesSoap.class.isAssignableFrom(serviceEndpointInterface)) {
                LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleFilesSoapStub _stub = new LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleFilesSoapStub(new java.net.URL(AWebServiceToHandleFilesSoap_address), this);
                _stub.setPortName(getAWebServiceToHandleFilesSoapWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("AWebServiceToHandleFilesSoap".equals(inputPortName)) {
            return getAWebServiceToHandleFilesSoap();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "AWebServiceToHandleFiles");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "AWebServiceToHandleFilesSoap"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("AWebServiceToHandleFilesSoap".equals(portName)) {
            setAWebServiceToHandleFilesSoapEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
