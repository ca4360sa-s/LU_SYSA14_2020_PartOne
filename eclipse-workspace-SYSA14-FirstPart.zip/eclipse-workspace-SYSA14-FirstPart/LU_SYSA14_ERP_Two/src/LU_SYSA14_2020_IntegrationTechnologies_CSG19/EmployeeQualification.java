/**
 * EmployeeQualification.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

public class EmployeeQualification  implements java.io.Serializable {
    private java.lang.String employeeNo_;

    private int lineNo_;

    private java.lang.String qualificationCode;

    private java.lang.String description;

    public EmployeeQualification() {
    }

    public EmployeeQualification(
           java.lang.String employeeNo_,
           int lineNo_,
           java.lang.String qualificationCode,
           java.lang.String description) {
           this.employeeNo_ = employeeNo_;
           this.lineNo_ = lineNo_;
           this.qualificationCode = qualificationCode;
           this.description = description;
    }


    /**
     * Gets the employeeNo_ value for this EmployeeQualification.
     * 
     * @return employeeNo_
     */
    public java.lang.String getEmployeeNo_() {
        return employeeNo_;
    }


    /**
     * Sets the employeeNo_ value for this EmployeeQualification.
     * 
     * @param employeeNo_
     */
    public void setEmployeeNo_(java.lang.String employeeNo_) {
        this.employeeNo_ = employeeNo_;
    }


    /**
     * Gets the lineNo_ value for this EmployeeQualification.
     * 
     * @return lineNo_
     */
    public int getLineNo_() {
        return lineNo_;
    }


    /**
     * Sets the lineNo_ value for this EmployeeQualification.
     * 
     * @param lineNo_
     */
    public void setLineNo_(int lineNo_) {
        this.lineNo_ = lineNo_;
    }


    /**
     * Gets the qualificationCode value for this EmployeeQualification.
     * 
     * @return qualificationCode
     */
    public java.lang.String getQualificationCode() {
        return qualificationCode;
    }


    /**
     * Sets the qualificationCode value for this EmployeeQualification.
     * 
     * @param qualificationCode
     */
    public void setQualificationCode(java.lang.String qualificationCode) {
        this.qualificationCode = qualificationCode;
    }


    /**
     * Gets the description value for this EmployeeQualification.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this EmployeeQualification.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EmployeeQualification)) return false;
        EmployeeQualification other = (EmployeeQualification) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.employeeNo_==null && other.getEmployeeNo_()==null) || 
             (this.employeeNo_!=null &&
              this.employeeNo_.equals(other.getEmployeeNo_()))) &&
            this.lineNo_ == other.getLineNo_() &&
            ((this.qualificationCode==null && other.getQualificationCode()==null) || 
             (this.qualificationCode!=null &&
              this.qualificationCode.equals(other.getQualificationCode()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEmployeeNo_() != null) {
            _hashCode += getEmployeeNo_().hashCode();
        }
        _hashCode += getLineNo_();
        if (getQualificationCode() != null) {
            _hashCode += getQualificationCode().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EmployeeQualification.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeQualification"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("employeeNo_");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeNo_"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lineNo_");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "LineNo_"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("qualificationCode");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "QualificationCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
