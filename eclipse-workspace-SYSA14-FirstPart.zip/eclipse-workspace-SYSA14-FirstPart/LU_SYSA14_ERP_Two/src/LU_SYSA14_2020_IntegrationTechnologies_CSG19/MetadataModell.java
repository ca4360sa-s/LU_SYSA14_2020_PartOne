/**
 * MetadataModell.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

public class MetadataModell  implements java.io.Serializable {
    private java.lang.String column_name;

    private int ordinal_position;

    private java.lang.String is_nullable;

    private java.lang.String data_type;

    private int character_maximum_length;

    public MetadataModell() {
    }

    public MetadataModell(
           java.lang.String column_name,
           int ordinal_position,
           java.lang.String is_nullable,
           java.lang.String data_type,
           int character_maximum_length) {
           this.column_name = column_name;
           this.ordinal_position = ordinal_position;
           this.is_nullable = is_nullable;
           this.data_type = data_type;
           this.character_maximum_length = character_maximum_length;
    }


    /**
     * Gets the column_name value for this MetadataModell.
     * 
     * @return column_name
     */
    public java.lang.String getColumn_name() {
        return column_name;
    }


    /**
     * Sets the column_name value for this MetadataModell.
     * 
     * @param column_name
     */
    public void setColumn_name(java.lang.String column_name) {
        this.column_name = column_name;
    }


    /**
     * Gets the ordinal_position value for this MetadataModell.
     * 
     * @return ordinal_position
     */
    public int getOrdinal_position() {
        return ordinal_position;
    }


    /**
     * Sets the ordinal_position value for this MetadataModell.
     * 
     * @param ordinal_position
     */
    public void setOrdinal_position(int ordinal_position) {
        this.ordinal_position = ordinal_position;
    }


    /**
     * Gets the is_nullable value for this MetadataModell.
     * 
     * @return is_nullable
     */
    public java.lang.String getIs_nullable() {
        return is_nullable;
    }


    /**
     * Sets the is_nullable value for this MetadataModell.
     * 
     * @param is_nullable
     */
    public void setIs_nullable(java.lang.String is_nullable) {
        this.is_nullable = is_nullable;
    }


    /**
     * Gets the data_type value for this MetadataModell.
     * 
     * @return data_type
     */
    public java.lang.String getData_type() {
        return data_type;
    }


    /**
     * Sets the data_type value for this MetadataModell.
     * 
     * @param data_type
     */
    public void setData_type(java.lang.String data_type) {
        this.data_type = data_type;
    }


    /**
     * Gets the character_maximum_length value for this MetadataModell.
     * 
     * @return character_maximum_length
     */
    public int getCharacter_maximum_length() {
        return character_maximum_length;
    }


    /**
     * Sets the character_maximum_length value for this MetadataModell.
     * 
     * @param character_maximum_length
     */
    public void setCharacter_maximum_length(int character_maximum_length) {
        this.character_maximum_length = character_maximum_length;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof MetadataModell)) return false;
        MetadataModell other = (MetadataModell) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.column_name==null && other.getColumn_name()==null) || 
             (this.column_name!=null &&
              this.column_name.equals(other.getColumn_name()))) &&
            this.ordinal_position == other.getOrdinal_position() &&
            ((this.is_nullable==null && other.getIs_nullable()==null) || 
             (this.is_nullable!=null &&
              this.is_nullable.equals(other.getIs_nullable()))) &&
            ((this.data_type==null && other.getData_type()==null) || 
             (this.data_type!=null &&
              this.data_type.equals(other.getData_type()))) &&
            this.character_maximum_length == other.getCharacter_maximum_length();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getColumn_name() != null) {
            _hashCode += getColumn_name().hashCode();
        }
        _hashCode += getOrdinal_position();
        if (getIs_nullable() != null) {
            _hashCode += getIs_nullable().hashCode();
        }
        if (getData_type() != null) {
            _hashCode += getData_type().hashCode();
        }
        _hashCode += getCharacter_maximum_length();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(MetadataModell.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "MetadataModell"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("column_name");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Column_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ordinal_position");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Ordinal_position"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("is_nullable");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Is_nullable"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_type");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Data_type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("character_maximum_length");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Character_maximum_length"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
