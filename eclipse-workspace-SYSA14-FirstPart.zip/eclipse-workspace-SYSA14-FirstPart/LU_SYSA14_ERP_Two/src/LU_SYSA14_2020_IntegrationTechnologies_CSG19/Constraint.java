/**
 * Constraint.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

public class Constraint  implements java.io.Serializable {
    private java.lang.String constraint_name;

    private java.lang.String constraint_type;

    public Constraint() {
    }

    public Constraint(
           java.lang.String constraint_name,
           java.lang.String constraint_type) {
           this.constraint_name = constraint_name;
           this.constraint_type = constraint_type;
    }


    /**
     * Gets the constraint_name value for this Constraint.
     * 
     * @return constraint_name
     */
    public java.lang.String getConstraint_name() {
        return constraint_name;
    }


    /**
     * Sets the constraint_name value for this Constraint.
     * 
     * @param constraint_name
     */
    public void setConstraint_name(java.lang.String constraint_name) {
        this.constraint_name = constraint_name;
    }


    /**
     * Gets the constraint_type value for this Constraint.
     * 
     * @return constraint_type
     */
    public java.lang.String getConstraint_type() {
        return constraint_type;
    }


    /**
     * Sets the constraint_type value for this Constraint.
     * 
     * @param constraint_type
     */
    public void setConstraint_type(java.lang.String constraint_type) {
        this.constraint_type = constraint_type;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Constraint)) return false;
        Constraint other = (Constraint) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.constraint_name==null && other.getConstraint_name()==null) || 
             (this.constraint_name!=null &&
              this.constraint_name.equals(other.getConstraint_name()))) &&
            ((this.constraint_type==null && other.getConstraint_type()==null) || 
             (this.constraint_type!=null &&
              this.constraint_type.equals(other.getConstraint_type())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getConstraint_name() != null) {
            _hashCode += getConstraint_name().hashCode();
        }
        if (getConstraint_type() != null) {
            _hashCode += getConstraint_type().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Constraint.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Constraint"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("constraint_name");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Constraint_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("constraint_type");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Constraint_type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
