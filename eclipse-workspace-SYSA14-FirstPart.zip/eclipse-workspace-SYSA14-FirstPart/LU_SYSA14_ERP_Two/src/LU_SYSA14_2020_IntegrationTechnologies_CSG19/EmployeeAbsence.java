/**
 * EmployeeAbsence.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

public class EmployeeAbsence  implements java.io.Serializable {
    private int entryNo_;

    private java.lang.String employeeNo_;

    private java.util.Calendar fromDate;

    private java.lang.String causeOfAbsenceCode;

    public EmployeeAbsence() {
    }

    public EmployeeAbsence(
           int entryNo_,
           java.lang.String employeeNo_,
           java.util.Calendar fromDate,
           java.lang.String causeOfAbsenceCode) {
           this.entryNo_ = entryNo_;
           this.employeeNo_ = employeeNo_;
           this.fromDate = fromDate;
           this.causeOfAbsenceCode = causeOfAbsenceCode;
    }


    /**
     * Gets the entryNo_ value for this EmployeeAbsence.
     * 
     * @return entryNo_
     */
    public int getEntryNo_() {
        return entryNo_;
    }


    /**
     * Sets the entryNo_ value for this EmployeeAbsence.
     * 
     * @param entryNo_
     */
    public void setEntryNo_(int entryNo_) {
        this.entryNo_ = entryNo_;
    }


    /**
     * Gets the employeeNo_ value for this EmployeeAbsence.
     * 
     * @return employeeNo_
     */
    public java.lang.String getEmployeeNo_() {
        return employeeNo_;
    }


    /**
     * Sets the employeeNo_ value for this EmployeeAbsence.
     * 
     * @param employeeNo_
     */
    public void setEmployeeNo_(java.lang.String employeeNo_) {
        this.employeeNo_ = employeeNo_;
    }


    /**
     * Gets the fromDate value for this EmployeeAbsence.
     * 
     * @return fromDate
     */
    public java.util.Calendar getFromDate() {
        return fromDate;
    }


    /**
     * Sets the fromDate value for this EmployeeAbsence.
     * 
     * @param fromDate
     */
    public void setFromDate(java.util.Calendar fromDate) {
        this.fromDate = fromDate;
    }


    /**
     * Gets the causeOfAbsenceCode value for this EmployeeAbsence.
     * 
     * @return causeOfAbsenceCode
     */
    public java.lang.String getCauseOfAbsenceCode() {
        return causeOfAbsenceCode;
    }


    /**
     * Sets the causeOfAbsenceCode value for this EmployeeAbsence.
     * 
     * @param causeOfAbsenceCode
     */
    public void setCauseOfAbsenceCode(java.lang.String causeOfAbsenceCode) {
        this.causeOfAbsenceCode = causeOfAbsenceCode;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EmployeeAbsence)) return false;
        EmployeeAbsence other = (EmployeeAbsence) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.entryNo_ == other.getEntryNo_() &&
            ((this.employeeNo_==null && other.getEmployeeNo_()==null) || 
             (this.employeeNo_!=null &&
              this.employeeNo_.equals(other.getEmployeeNo_()))) &&
            ((this.fromDate==null && other.getFromDate()==null) || 
             (this.fromDate!=null &&
              this.fromDate.equals(other.getFromDate()))) &&
            ((this.causeOfAbsenceCode==null && other.getCauseOfAbsenceCode()==null) || 
             (this.causeOfAbsenceCode!=null &&
              this.causeOfAbsenceCode.equals(other.getCauseOfAbsenceCode())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getEntryNo_();
        if (getEmployeeNo_() != null) {
            _hashCode += getEmployeeNo_().hashCode();
        }
        if (getFromDate() != null) {
            _hashCode += getFromDate().hashCode();
        }
        if (getCauseOfAbsenceCode() != null) {
            _hashCode += getCauseOfAbsenceCode().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EmployeeAbsence.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeAbsence"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("entryNo_");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EntryNo_"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("employeeNo_");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeNo_"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fromDate");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "FromDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("causeOfAbsenceCode");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "CauseOfAbsenceCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
