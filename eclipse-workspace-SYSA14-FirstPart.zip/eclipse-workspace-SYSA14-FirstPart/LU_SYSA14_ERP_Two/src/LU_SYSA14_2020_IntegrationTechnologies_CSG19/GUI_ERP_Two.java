package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLayeredPane;
import javax.swing.border.EtchedBorder;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GUI_ERP_Two {

	private JFrame frameERPTwo;
	private JTable tableDisplayData;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI_ERP_Two window = new GUI_ERP_Two();
					window.frameERPTwo.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUI_ERP_Two() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frameERPTwo = new JFrame();
		frameERPTwo.setTitle("ERP-integration Uppgift 2");
		frameERPTwo.setBounds(100, 100, 830, 600);
		frameERPTwo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameERPTwo.getContentPane().setLayout(null);
		Controller_ERP_Two controller = new Controller_ERP_Two(); 
		
		JLabel lblHeadInfo = new JLabel("CRONUS Employees - Klient 2");
		lblHeadInfo.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblHeadInfo.setBounds(260, 36, 252, 28);
		frameERPTwo.getContentPane().add(lblHeadInfo);
		
		JLabel lblERPTwoNF = new JLabel("New label");
		lblERPTwoNF.setForeground(new Color(204, 51, 51));
		lblERPTwoNF.setBounds(41, 238, 337, 18);
		frameERPTwo.getContentPane().add(lblERPTwoNF);
		lblERPTwoNF.setVisible(false);
		
		JLabel lblERPTwoPF = new JLabel("New label");
		lblERPTwoPF.setForeground(new Color(0, 153, 51));
		lblERPTwoPF.setBounds(41, 238, 337, 18);
		frameERPTwo.getContentPane().add(lblERPTwoPF);
		lblERPTwoPF.setVisible(false);
		
		JScrollPane scrollPaneERPTwo = new JScrollPane();
		scrollPaneERPTwo.setBounds(41, 266, 732, 271);
		frameERPTwo.getContentPane().add(scrollPaneERPTwo);
		
		tableDisplayData = new JTable();
		scrollPaneERPTwo.setViewportView(tableDisplayData);
		
		JLayeredPane layeredPaneOtherTables = new JLayeredPane();
		layeredPaneOtherTables.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Visningsalternativ f\u00F6r \u00F6vriga querys", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		layeredPaneOtherTables.setBounds(412, 109, 361, 130);
		frameERPTwo.getContentPane().add(layeredPaneOtherTables);
		layeredPaneOtherTables.setLayout(null);
		layeredPaneOtherTables.setVisible(false);
		
		JComboBox<String> comboBoxOtherTable = new JComboBox();
		comboBoxOtherTable.setBounds(10, 50, 341, 21);
		layeredPaneOtherTables.add(comboBoxOtherTable);
		comboBoxOtherTable.addItem("Anst�llda och dess anh�riga");
		comboBoxOtherTable.addItem("Anst�llda som varit borta p.g.a. sjukdom under 2004");
		comboBoxOtherTable.addItem("F�rnamn f�r anst�lld med l�ngs sjukfr�nvaro");
		comboBoxOtherTable.addItem("Alla nycklar i CRONUS-databasen");
		comboBoxOtherTable.addItem("Alla index i CRONUS-databasen");
		comboBoxOtherTable.addItem("Alla constraints f�r samtliga tabeller");
		comboBoxOtherTable.addItem("Alla tabeller i CRONUS-databasen (alt. 1)");
		comboBoxOtherTable.addItem("Alla tabeller i CRONUS-databasen (alt. 2)");
		comboBoxOtherTable.addItem("Alla kolumner i CRONUS-databasen (alt. 1)");
		comboBoxOtherTable.addItem("Alla kolumner i CRONUS-databasen (alt. 2)");
		
		JLayeredPane layeredPaneERTables = new JLayeredPane();
		layeredPaneERTables.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Visningsalternativ f\u00F6r Employee och relaterade tabeller", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		layeredPaneERTables.setBounds(412, 109, 361, 130);
		frameERPTwo.getContentPane().add(layeredPaneERTables);
		layeredPaneERTables.setLayout(null);
		
		JComboBox<String> comboBoxERTables = new JComboBox();
		comboBoxERTables.setBounds(10, 50, 341, 21);
		layeredPaneERTables.add(comboBoxERTables);
		comboBoxERTables.addItem("Employee");
		comboBoxERTables.addItem("Employee Absence");
		comboBoxERTables.addItem("Employee Qualification");
		comboBoxERTables.addItem("Employee Relative");
		comboBoxERTables.addItem("Employee Statistics Group");
		comboBoxERTables.addItem("Employment Contract");
		
		JRadioButton rdbtnERContent = new JRadioButton("Inneh\u00E5ll");
		buttonGroup.add(rdbtnERContent);
		rdbtnERContent.setSelected(true);
		rdbtnERContent.setBounds(6, 20, 71, 21);
		layeredPaneERTables.add(rdbtnERContent);
		
		JRadioButton rdbtnERMetadata = new JRadioButton("Metadata");
		buttonGroup.add(rdbtnERMetadata);
		rdbtnERMetadata.setBounds(91, 20, 105, 21);
		layeredPaneERTables.add(rdbtnERMetadata);
		
		JRadioButton rdbtnContentAndMetadata = new JRadioButton("Inneh\u00E5ll och metadata f\u00F6r Employee och relaterade tabeller");
		rdbtnContentAndMetadata.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				layeredPaneERTables.setVisible(true);
				layeredPaneOtherTables.setVisible(false);
			}
		});
		buttonGroup_1.add(rdbtnContentAndMetadata);
		rdbtnContentAndMetadata.setSelected(true);
		rdbtnContentAndMetadata.setBounds(41, 109, 365, 21);
		frameERPTwo.getContentPane().add(rdbtnContentAndMetadata);
		
		JRadioButton rdbtnOtherQueries = new JRadioButton("\u00D6vriga queries");
		rdbtnOtherQueries.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				layeredPaneERTables.setVisible(false);
				layeredPaneOtherTables.setVisible(true);
				
			}
		});
		buttonGroup_1.add(rdbtnOtherQueries);
		rdbtnOtherQueries.setBounds(41, 132, 331, 21);
		frameERPTwo.getContentPane().add(rdbtnOtherQueries);
		
		JButton btnER = new JButton("Visa");
		btnER.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lblERPTwoPF.setVisible(false);
				lblERPTwoNF.setVisible(false); 
				String input = comboBoxERTables.getSelectedItem().toString(); 
				DefaultTableModel model = new DefaultTableModel(); 
				tableDisplayData.setModel(model); 
				
				if(rdbtnERMetadata.isSelected()) {
					//Metadata
					String tableName = "CRONUS Sverige AB$"+input; 
					model = controller.DisplayMetadata(tableName); 
					if(model.getRowCount() > 0) {
						tableDisplayData.setModel(model);
						lblERPTwoPF.setText("Resultatet visas");
						lblERPTwoPF.setVisible(true);
					}
					else {
						lblERPTwoNF.setText("Finns ingen metadata f�r tabellen");
						lblERPTwoNF.setVisible(true);
					}
				}
				else if(rdbtnERContent.isSelected()) {

					
					if(input  == "Employee") {
						model = controller.DisplayEmployee(); 
						if(model.getRowCount() > 0) {
							tableDisplayData.setModel(model);
							lblERPTwoPF.setText("Resultatet visas");
							lblERPTwoPF.setVisible(true);
						}
						else {
							lblERPTwoNF.setText("Finns ingen metadata f�r tabellen");
							lblERPTwoNF.setVisible(true);
						}
					}
					if(input == "Employee Absence") {
						model = controller.DisplayEmployeeAbsence(); 
						if(model.getRowCount() > 0) {
							tableDisplayData.setModel(model);
							lblERPTwoPF.setText("Resultatet visas");
							lblERPTwoPF.setVisible(true);
						}
						else {
							lblERPTwoNF.setText("Finns ingen metadata f�r tabellen");
							lblERPTwoNF.setVisible(true);
						}
					}
					if(input == "Employee Qualification") {
						model = controller.DisplayEmployeeQualification();
						if(model.getRowCount() > 0) {
							tableDisplayData.setModel(model);
							lblERPTwoPF.setText("Resultatet visas");
							lblERPTwoPF.setVisible(true);
						}
						else {
							lblERPTwoNF.setText("Finns ingen metadata f�r tabellen");
							lblERPTwoNF.setVisible(true);
						}
					}
					if(input == "Employee Relative") {
						model = controller.DisplayEmployeeAndRelative();
						if(model.getRowCount() > 0) {
							tableDisplayData.setModel(model);
							lblERPTwoPF.setText("Resultatet visas");
							lblERPTwoPF.setVisible(true);
						}
						else {
							lblERPTwoNF.setText("Finns ingen metadata f�r tabellen");
							lblERPTwoNF.setVisible(true);
						}
					}
					if(input == "Employee Statistics Group") {
						model = controller.DisplayEmployeeStatisticsGroup();
						if(model.getRowCount() > 0) {
							tableDisplayData.setModel(model);
							lblERPTwoPF.setText("Resultatet visas");
							lblERPTwoPF.setVisible(true);
						}
						else {
							lblERPTwoNF.setText("Finns ingen metadata f�r tabellen");
							lblERPTwoNF.setVisible(true);
						}
					}
					if(input == "Employment Contract") {
						model = controller.DisplayEmploymentContract(); 
						if(model.getRowCount() > 0) {
							tableDisplayData.setModel(model);
							lblERPTwoPF.setText("Resultatet visas");
							lblERPTwoPF.setVisible(true);
						}
						else {
							lblERPTwoNF.setText("Finns ingen metadata f�r tabellen");
							lblERPTwoNF.setVisible(true);
						}
					}
				}
			}
		});
		btnER.setBounds(140, 99, 85, 21);
		layeredPaneERTables.add(btnER);		
		
		JButton btnOtherTables = new JButton("Visa");
		btnOtherTables.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lblERPTwoNF.setVisible(false);
				lblERPTwoPF.setVisible(false);
				String input = comboBoxOtherTable.getSelectedItem().toString(); 
				DefaultTableModel model = new DefaultTableModel(); 
				tableDisplayData.setModel(model); 
				if(input == "Anst�llda och dess anh�riga") {
					model = controller.DisplayEmployeeAndRelative();
					if(model.getRowCount() > 0) {
						tableDisplayData.setModel(model); 
						lblERPTwoPF.setText("Resultatet visas");
						lblERPTwoPF.setVisible(true);
					}
					else {
						lblERPTwoNF.setText("Tabellen har ingen data");
						lblERPTwoNF.setVisible(true);
					}
					
				}
				if(input == "Anst�llda som varit borta p.g.a. sjukdom under 2004") {				
					model = controller.DisplayEmployeeAbsence();
					if(model.getRowCount() > 0) {
						tableDisplayData.setModel(model); 
						lblERPTwoPF.setText("Resultatet visas");
						lblERPTwoPF.setVisible(true);
					}
					else {
						lblERPTwoNF.setText("Tabellen har ingen data");
						lblERPTwoNF.setVisible(true);
					}
				}
				if(input == "F�rnamn f�r anst�lld med l�ngs sjukfr�nvaro") {				
					model = controller.DisplayEmployeeMostAbsentDuring2004();
					if(model.getRowCount() > 0) {
						tableDisplayData.setModel(model); 
						lblERPTwoPF.setText("Resultatet visas");
						lblERPTwoPF.setVisible(true);
					}
					else {
						lblERPTwoNF.setText("Tabellen har ingen data");
						lblERPTwoNF.setVisible(true);
					}
				}
				if(input == "Alla nycklar i CRONUS-databasen") {				
					model = controller.DisplayAllKeys();
					if(model.getRowCount() > 0) {
						tableDisplayData.setModel(model); 
						lblERPTwoPF.setText("Resultatet visas");
						lblERPTwoPF.setVisible(true);
					}
					else {
						lblERPTwoNF.setText("Tabellen har ingen data");
						lblERPTwoNF.setVisible(true);
					}
				}
				if(input == "Alla index i CRONUS-databasen") {
					model = controller.DisplayAllIndexes();
					if(model.getRowCount() > 0) {
						tableDisplayData.setModel(model); 
						lblERPTwoPF.setText("Resultatet visas");
						lblERPTwoPF.setVisible(true);
					}
					else {
						lblERPTwoNF.setText("Tabellen har ingen data");
						lblERPTwoNF.setVisible(true);
					}
					
				}
				if(input == "Alla constraints f�r samtliga tabeller") {
					model = controller.DisplayAllConstraints();
					if(model.getRowCount() > 0) {
						tableDisplayData.setModel(model); 
						lblERPTwoPF.setText("Resultatet visas");
						lblERPTwoPF.setVisible(true);
					}
					else {
						lblERPTwoNF.setText("Tabellen har ingen data");
						lblERPTwoNF.setVisible(true);
					}
					
				}
				if(input == "Alla tabeller i CRONUS-databasen (alt. 1)") {
					model = controller.DisplayAllTablesViaINFORMATION_SCHEMA();
					if(model.getRowCount() > 0) {
						tableDisplayData.setModel(model); 
						lblERPTwoPF.setText("Resultatet visas");
						lblERPTwoPF.setVisible(true);
					}
					else {
						lblERPTwoNF.setText("Tabellen har ingen data");
						lblERPTwoNF.setVisible(true);
					}
					
				}
				if(input == "Alla tabeller i CRONUS-databasen (alt. 2)") {
					model = controller.DisplayAllTablesViaSYSOBJECT();
					if(model.getRowCount() > 0) {
						tableDisplayData.setModel(model); 
						lblERPTwoPF.setText("Resultatet visas");
						lblERPTwoPF.setVisible(true);
					}
					else {
						lblERPTwoNF.setText("Tabellen har ingen data");
						lblERPTwoNF.setVisible(true);
					}
					
				}
				if(input == "Alla kolumner i CRONUS-databasen (alt. 1)") {
					model = controller.DisplayAllColumsViaINFORMATION_SCHEMA();
					if(model.getRowCount() > 0) {
						tableDisplayData.setModel(model); 
						lblERPTwoPF.setText("Resultatet visas");
						lblERPTwoPF.setVisible(true);
					}
					else {
						lblERPTwoNF.setText("Tabellen har ingen data");
						lblERPTwoNF.setVisible(true);
					}
					
				}
				if(input == "Alla kolumner i CRONUS-databasen (alt. 2)") {
					model = controller.DisplayAllColumsViaSYS();
					if(model.getRowCount() > 0) {
						tableDisplayData.setModel(model); 
						lblERPTwoPF.setText("Resultatet visas");
						lblERPTwoPF.setVisible(true);
					}
					else {
						lblERPTwoNF.setText("Tabellen har ingen data");
						lblERPTwoNF.setVisible(true);
					}
					
				}

			}
		});
		btnOtherTables.setBounds(140, 99, 85, 21);
		layeredPaneOtherTables.add(btnOtherTables);
	}
}
