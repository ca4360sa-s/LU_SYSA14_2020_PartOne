/**
 * AWebServiceForContentAndMetadataFromCRONUSSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

public interface AWebServiceForContentAndMetadataFromCRONUSSoap extends java.rmi.Remote {
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.MetadataModell[] displayMetadataFromTable(java.lang.String tableName) throws java.rmi.RemoteException;
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[] displayEmployee() throws java.rmi.RemoteException;
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAbsence[] displayEmployeeAbsence() throws java.rmi.RemoteException;
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeQualification[] displayEmployeeQualification() throws java.rmi.RemoteException;
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeStatisticsGroup[] displayEmployeeStatisticsGroup() throws java.rmi.RemoteException;
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmploymentContract[] displayEmploymentContract() throws java.rmi.RemoteException;
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAndRelative[] displayEmployeesAndRelatives() throws java.rmi.RemoteException;
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[] displayEmployeesSickDuring2004() throws java.rmi.RemoteException;
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[] displayEmployeeMostAbsentDuring2004() throws java.rmi.RemoteException;
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Key[] displayAllKeys() throws java.rmi.RemoteException;
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Index[] displayAllIndexes() throws java.rmi.RemoteException;
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Constraint[] displayAllConstraints() throws java.rmi.RemoteException;
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Table[] displayAllTablesViaINFORMTION_SCHEMA() throws java.rmi.RemoteException;
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Table[] displayAllTablesViaSYSOBJECT() throws java.rmi.RemoteException;
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Colum[] displayAllColumsViaINFORMATION_SCHEMA() throws java.rmi.RemoteException;
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Colum[] displayALLColumsViaSYS() throws java.rmi.RemoteException;
}
