package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

public class AWebServiceForContentAndMetadataFromCRONUSSoapProxy implements LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceForContentAndMetadataFromCRONUSSoap {
  private String _endpoint = null;
  private LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceForContentAndMetadataFromCRONUSSoap aWebServiceForContentAndMetadataFromCRONUSSoap = null;
  
  public AWebServiceForContentAndMetadataFromCRONUSSoapProxy() {
    _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
  }
  
  public AWebServiceForContentAndMetadataFromCRONUSSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
  }
  
  private void _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy() {
    try {
      aWebServiceForContentAndMetadataFromCRONUSSoap = (new LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceForContentAndMetadataFromCRONUSLocator()).getAWebServiceForContentAndMetadataFromCRONUSSoap();
      if (aWebServiceForContentAndMetadataFromCRONUSSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)aWebServiceForContentAndMetadataFromCRONUSSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)aWebServiceForContentAndMetadataFromCRONUSSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (aWebServiceForContentAndMetadataFromCRONUSSoap != null)
      ((javax.xml.rpc.Stub)aWebServiceForContentAndMetadataFromCRONUSSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceForContentAndMetadataFromCRONUSSoap getAWebServiceForContentAndMetadataFromCRONUSSoap() {
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap;
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.MetadataModell[] displayMetadataFromTable(java.lang.String tableName) throws java.rmi.RemoteException{
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap.displayMetadataFromTable(tableName);
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[] displayEmployee() throws java.rmi.RemoteException{
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap.displayEmployee();
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAbsence[] displayEmployeeAbsence() throws java.rmi.RemoteException{
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap.displayEmployeeAbsence();
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeQualification[] displayEmployeeQualification() throws java.rmi.RemoteException{
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap.displayEmployeeQualification();
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeStatisticsGroup[] displayEmployeeStatisticsGroup() throws java.rmi.RemoteException{
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap.displayEmployeeStatisticsGroup();
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmploymentContract[] displayEmploymentContract() throws java.rmi.RemoteException{
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap.displayEmploymentContract();
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAndRelative[] displayEmployeesAndRelatives() throws java.rmi.RemoteException{
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap.displayEmployeesAndRelatives();
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[] displayEmployeesSickDuring2004() throws java.rmi.RemoteException{
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap.displayEmployeesSickDuring2004();
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[] displayEmployeeMostAbsentDuring2004() throws java.rmi.RemoteException{
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap.displayEmployeeMostAbsentDuring2004();
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Key[] displayAllKeys() throws java.rmi.RemoteException{
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap.displayAllKeys();
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Index[] displayAllIndexes() throws java.rmi.RemoteException{
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap.displayAllIndexes();
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Constraint[] displayAllConstraints() throws java.rmi.RemoteException{
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap.displayAllConstraints();
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Table[] displayAllTablesViaINFORMTION_SCHEMA() throws java.rmi.RemoteException{
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap.displayAllTablesViaINFORMTION_SCHEMA();
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Table[] displayAllTablesViaSYSOBJECT() throws java.rmi.RemoteException{
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap.displayAllTablesViaSYSOBJECT();
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Colum[] displayAllColumsViaINFORMATION_SCHEMA() throws java.rmi.RemoteException{
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap.displayAllColumsViaINFORMATION_SCHEMA();
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Colum[] displayALLColumsViaSYS() throws java.rmi.RemoteException{
    if (aWebServiceForContentAndMetadataFromCRONUSSoap == null)
      _initAWebServiceForContentAndMetadataFromCRONUSSoapProxy();
    return aWebServiceForContentAndMetadataFromCRONUSSoap.displayALLColumsViaSYS();
  }
  
  
}