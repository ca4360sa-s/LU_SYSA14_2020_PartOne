/**
 * EmployeeAndRelative.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

public class EmployeeAndRelative  implements java.io.Serializable {
    private java.lang.String employeeNo_;

    private int lineNo_;

    private java.lang.String relativeCode;

    private java.lang.String firstName;

    private java.lang.String lastName;

    public EmployeeAndRelative() {
    }

    public EmployeeAndRelative(
           java.lang.String employeeNo_,
           int lineNo_,
           java.lang.String relativeCode,
           java.lang.String firstName,
           java.lang.String lastName) {
           this.employeeNo_ = employeeNo_;
           this.lineNo_ = lineNo_;
           this.relativeCode = relativeCode;
           this.firstName = firstName;
           this.lastName = lastName;
    }


    /**
     * Gets the employeeNo_ value for this EmployeeAndRelative.
     * 
     * @return employeeNo_
     */
    public java.lang.String getEmployeeNo_() {
        return employeeNo_;
    }


    /**
     * Sets the employeeNo_ value for this EmployeeAndRelative.
     * 
     * @param employeeNo_
     */
    public void setEmployeeNo_(java.lang.String employeeNo_) {
        this.employeeNo_ = employeeNo_;
    }


    /**
     * Gets the lineNo_ value for this EmployeeAndRelative.
     * 
     * @return lineNo_
     */
    public int getLineNo_() {
        return lineNo_;
    }


    /**
     * Sets the lineNo_ value for this EmployeeAndRelative.
     * 
     * @param lineNo_
     */
    public void setLineNo_(int lineNo_) {
        this.lineNo_ = lineNo_;
    }


    /**
     * Gets the relativeCode value for this EmployeeAndRelative.
     * 
     * @return relativeCode
     */
    public java.lang.String getRelativeCode() {
        return relativeCode;
    }


    /**
     * Sets the relativeCode value for this EmployeeAndRelative.
     * 
     * @param relativeCode
     */
    public void setRelativeCode(java.lang.String relativeCode) {
        this.relativeCode = relativeCode;
    }


    /**
     * Gets the firstName value for this EmployeeAndRelative.
     * 
     * @return firstName
     */
    public java.lang.String getFirstName() {
        return firstName;
    }


    /**
     * Sets the firstName value for this EmployeeAndRelative.
     * 
     * @param firstName
     */
    public void setFirstName(java.lang.String firstName) {
        this.firstName = firstName;
    }


    /**
     * Gets the lastName value for this EmployeeAndRelative.
     * 
     * @return lastName
     */
    public java.lang.String getLastName() {
        return lastName;
    }


    /**
     * Sets the lastName value for this EmployeeAndRelative.
     * 
     * @param lastName
     */
    public void setLastName(java.lang.String lastName) {
        this.lastName = lastName;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EmployeeAndRelative)) return false;
        EmployeeAndRelative other = (EmployeeAndRelative) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.employeeNo_==null && other.getEmployeeNo_()==null) || 
             (this.employeeNo_!=null &&
              this.employeeNo_.equals(other.getEmployeeNo_()))) &&
            this.lineNo_ == other.getLineNo_() &&
            ((this.relativeCode==null && other.getRelativeCode()==null) || 
             (this.relativeCode!=null &&
              this.relativeCode.equals(other.getRelativeCode()))) &&
            ((this.firstName==null && other.getFirstName()==null) || 
             (this.firstName!=null &&
              this.firstName.equals(other.getFirstName()))) &&
            ((this.lastName==null && other.getLastName()==null) || 
             (this.lastName!=null &&
              this.lastName.equals(other.getLastName())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEmployeeNo_() != null) {
            _hashCode += getEmployeeNo_().hashCode();
        }
        _hashCode += getLineNo_();
        if (getRelativeCode() != null) {
            _hashCode += getRelativeCode().hashCode();
        }
        if (getFirstName() != null) {
            _hashCode += getFirstName().hashCode();
        }
        if (getLastName() != null) {
            _hashCode += getLastName().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EmployeeAndRelative.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeAndRelative"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("employeeNo_");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeNo_"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lineNo_");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "LineNo_"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relativeCode");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "RelativeCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstName");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "FirstName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastName");
        elemField.setXmlName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "LastName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
