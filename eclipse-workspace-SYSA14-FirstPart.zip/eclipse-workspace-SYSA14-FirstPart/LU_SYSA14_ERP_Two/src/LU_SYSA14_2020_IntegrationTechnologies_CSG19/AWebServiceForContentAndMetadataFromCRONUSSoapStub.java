/**
 * AWebServiceForContentAndMetadataFromCRONUSSoapStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

public class AWebServiceForContentAndMetadataFromCRONUSSoapStub extends org.apache.axis.client.Stub implements LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceForContentAndMetadataFromCRONUSSoap {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[16];
        _initOperationDesc1();
        _initOperationDesc2();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DisplayMetadataFromTable");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "tableName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfMetadataModell"));
        oper.setReturnClass(LU_SYSA14_2020_IntegrationTechnologies_CSG19.MetadataModell[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayMetadataFromTableResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "MetadataModell"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DisplayEmployee");
        oper.setReturnType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfEmployee"));
        oper.setReturnClass(LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayEmployeeResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Employee"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DisplayEmployeeAbsence");
        oper.setReturnType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfEmployeeAbsence"));
        oper.setReturnClass(LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAbsence[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayEmployeeAbsenceResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeAbsence"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DisplayEmployeeQualification");
        oper.setReturnType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfEmployeeQualification"));
        oper.setReturnClass(LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeQualification[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayEmployeeQualificationResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeQualification"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DisplayEmployeeStatisticsGroup");
        oper.setReturnType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfEmployeeStatisticsGroup"));
        oper.setReturnClass(LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeStatisticsGroup[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayEmployeeStatisticsGroupResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeStatisticsGroup"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DisplayEmploymentContract");
        oper.setReturnType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfEmploymentContract"));
        oper.setReturnClass(LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmploymentContract[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayEmploymentContractResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmploymentContract"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DisplayEmployeesAndRelatives");
        oper.setReturnType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfEmployeeAndRelative"));
        oper.setReturnClass(LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAndRelative[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayEmployeesAndRelativesResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeAndRelative"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DisplayEmployeesSickDuring2004");
        oper.setReturnType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfEmployee"));
        oper.setReturnClass(LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayEmployeesSickDuring2004Result"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Employee"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DisplayEmployeeMostAbsentDuring2004");
        oper.setReturnType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfEmployee"));
        oper.setReturnClass(LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayEmployeeMostAbsentDuring2004Result"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Employee"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DisplayAllKeys");
        oper.setReturnType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfKey"));
        oper.setReturnClass(LU_SYSA14_2020_IntegrationTechnologies_CSG19.Key[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayAllKeysResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Key"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DisplayAllIndexes");
        oper.setReturnType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfIndex"));
        oper.setReturnClass(LU_SYSA14_2020_IntegrationTechnologies_CSG19.Index[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayAllIndexesResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Index"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DisplayAllConstraints");
        oper.setReturnType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfConstraint"));
        oper.setReturnClass(LU_SYSA14_2020_IntegrationTechnologies_CSG19.Constraint[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayAllConstraintsResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Constraint"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DisplayAllTablesViaINFORMTION_SCHEMA");
        oper.setReturnType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfTable"));
        oper.setReturnClass(LU_SYSA14_2020_IntegrationTechnologies_CSG19.Table[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayAllTablesViaINFORMTION_SCHEMAResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Table"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DisplayAllTablesViaSYSOBJECT");
        oper.setReturnType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfTable"));
        oper.setReturnClass(LU_SYSA14_2020_IntegrationTechnologies_CSG19.Table[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayAllTablesViaSYSOBJECTResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Table"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DisplayAllColumsViaINFORMATION_SCHEMA");
        oper.setReturnType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfColum"));
        oper.setReturnClass(LU_SYSA14_2020_IntegrationTechnologies_CSG19.Colum[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayAllColumsViaINFORMATION_SCHEMAResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Colum"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DisplayALLColumsViaSYS");
        oper.setReturnType(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfColum"));
        oper.setReturnClass(LU_SYSA14_2020_IntegrationTechnologies_CSG19.Colum[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayALLColumsViaSYSResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Colum"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[15] = oper;

    }

    public AWebServiceForContentAndMetadataFromCRONUSSoapStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public AWebServiceForContentAndMetadataFromCRONUSSoapStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public AWebServiceForContentAndMetadataFromCRONUSSoapStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfColum");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.Colum[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Colum");
            qName2 = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Colum");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfConstraint");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.Constraint[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Constraint");
            qName2 = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Constraint");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfEmployee");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Employee");
            qName2 = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Employee");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfEmployeeAbsence");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAbsence[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeAbsence");
            qName2 = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeAbsence");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfEmployeeAndRelative");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAndRelative[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeAndRelative");
            qName2 = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeAndRelative");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfEmployeeQualification");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeQualification[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeQualification");
            qName2 = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeQualification");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfEmployeeStatisticsGroup");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeStatisticsGroup[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeStatisticsGroup");
            qName2 = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeStatisticsGroup");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfEmploymentContract");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmploymentContract[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmploymentContract");
            qName2 = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmploymentContract");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfIndex");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.Index[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Index");
            qName2 = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Index");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfKey");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.Key[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Key");
            qName2 = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Key");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfMetadataModell");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.MetadataModell[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "MetadataModell");
            qName2 = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "MetadataModell");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "ArrayOfTable");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.Table[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Table");
            qName2 = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Table");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Colum");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.Colum.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Constraint");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.Constraint.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Employee");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeAbsence");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAbsence.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeAndRelative");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAndRelative.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeQualification");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeQualification.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmployeeStatisticsGroup");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeStatisticsGroup.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "EmploymentContract");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmploymentContract.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Index");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.Index.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Key");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.Key.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "MetadataModell");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.MetadataModell.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "Table");
            cachedSerQNames.add(qName);
            cls = LU_SYSA14_2020_IntegrationTechnologies_CSG19.Table.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.MetadataModell[] displayMetadataFromTable(java.lang.String tableName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("LU_SYSA14_2020_IntegrationTechnologies_CSG19/DisplayMetadataFromTable");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayMetadataFromTable"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {tableName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.MetadataModell[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.MetadataModell[]) org.apache.axis.utils.JavaUtils.convert(_resp, LU_SYSA14_2020_IntegrationTechnologies_CSG19.MetadataModell[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[] displayEmployee() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("LU_SYSA14_2020_IntegrationTechnologies_CSG19/DisplayEmployee");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayEmployee"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[]) org.apache.axis.utils.JavaUtils.convert(_resp, LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAbsence[] displayEmployeeAbsence() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("LU_SYSA14_2020_IntegrationTechnologies_CSG19/DisplayEmployeeAbsence");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayEmployeeAbsence"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAbsence[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAbsence[]) org.apache.axis.utils.JavaUtils.convert(_resp, LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAbsence[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeQualification[] displayEmployeeQualification() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("LU_SYSA14_2020_IntegrationTechnologies_CSG19/DisplayEmployeeQualification");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayEmployeeQualification"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeQualification[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeQualification[]) org.apache.axis.utils.JavaUtils.convert(_resp, LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeQualification[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeStatisticsGroup[] displayEmployeeStatisticsGroup() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("LU_SYSA14_2020_IntegrationTechnologies_CSG19/DisplayEmployeeStatisticsGroup");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayEmployeeStatisticsGroup"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeStatisticsGroup[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeStatisticsGroup[]) org.apache.axis.utils.JavaUtils.convert(_resp, LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeStatisticsGroup[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmploymentContract[] displayEmploymentContract() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("LU_SYSA14_2020_IntegrationTechnologies_CSG19/DisplayEmploymentContract");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayEmploymentContract"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmploymentContract[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmploymentContract[]) org.apache.axis.utils.JavaUtils.convert(_resp, LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmploymentContract[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAndRelative[] displayEmployeesAndRelatives() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("LU_SYSA14_2020_IntegrationTechnologies_CSG19/DisplayEmployeesAndRelatives");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayEmployeesAndRelatives"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAndRelative[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAndRelative[]) org.apache.axis.utils.JavaUtils.convert(_resp, LU_SYSA14_2020_IntegrationTechnologies_CSG19.EmployeeAndRelative[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[] displayEmployeesSickDuring2004() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("LU_SYSA14_2020_IntegrationTechnologies_CSG19/DisplayEmployeesSickDuring2004");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayEmployeesSickDuring2004"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[]) org.apache.axis.utils.JavaUtils.convert(_resp, LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[] displayEmployeeMostAbsentDuring2004() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("LU_SYSA14_2020_IntegrationTechnologies_CSG19/DisplayEmployeeMostAbsentDuring2004");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayEmployeeMostAbsentDuring2004"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[]) org.apache.axis.utils.JavaUtils.convert(_resp, LU_SYSA14_2020_IntegrationTechnologies_CSG19.Employee[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Key[] displayAllKeys() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("LU_SYSA14_2020_IntegrationTechnologies_CSG19/DisplayAllKeys");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayAllKeys"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Key[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Key[]) org.apache.axis.utils.JavaUtils.convert(_resp, LU_SYSA14_2020_IntegrationTechnologies_CSG19.Key[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Index[] displayAllIndexes() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("LU_SYSA14_2020_IntegrationTechnologies_CSG19/DisplayAllIndexes");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayAllIndexes"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Index[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Index[]) org.apache.axis.utils.JavaUtils.convert(_resp, LU_SYSA14_2020_IntegrationTechnologies_CSG19.Index[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Constraint[] displayAllConstraints() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("LU_SYSA14_2020_IntegrationTechnologies_CSG19/DisplayAllConstraints");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayAllConstraints"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Constraint[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Constraint[]) org.apache.axis.utils.JavaUtils.convert(_resp, LU_SYSA14_2020_IntegrationTechnologies_CSG19.Constraint[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Table[] displayAllTablesViaINFORMTION_SCHEMA() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("LU_SYSA14_2020_IntegrationTechnologies_CSG19/DisplayAllTablesViaINFORMTION_SCHEMA");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayAllTablesViaINFORMTION_SCHEMA"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Table[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Table[]) org.apache.axis.utils.JavaUtils.convert(_resp, LU_SYSA14_2020_IntegrationTechnologies_CSG19.Table[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Table[] displayAllTablesViaSYSOBJECT() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("LU_SYSA14_2020_IntegrationTechnologies_CSG19/DisplayAllTablesViaSYSOBJECT");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayAllTablesViaSYSOBJECT"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Table[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Table[]) org.apache.axis.utils.JavaUtils.convert(_resp, LU_SYSA14_2020_IntegrationTechnologies_CSG19.Table[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Colum[] displayAllColumsViaINFORMATION_SCHEMA() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("LU_SYSA14_2020_IntegrationTechnologies_CSG19/DisplayAllColumsViaINFORMATION_SCHEMA");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayAllColumsViaINFORMATION_SCHEMA"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Colum[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Colum[]) org.apache.axis.utils.JavaUtils.convert(_resp, LU_SYSA14_2020_IntegrationTechnologies_CSG19.Colum[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Colum[] displayALLColumsViaSYS() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("LU_SYSA14_2020_IntegrationTechnologies_CSG19/DisplayALLColumsViaSYS");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("LU_SYSA14_2020_IntegrationTechnologies_CSG19", "DisplayALLColumsViaSYS"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Colum[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (LU_SYSA14_2020_IntegrationTechnologies_CSG19.Colum[]) org.apache.axis.utils.JavaUtils.convert(_resp, LU_SYSA14_2020_IntegrationTechnologies_CSG19.Colum[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
