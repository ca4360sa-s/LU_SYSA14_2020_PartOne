package LU_SYSA14_2020_IntegrationTechnologies_CSG19;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.accessibility.*;
import javax.mail.*;
import javax.swing.table.DefaultTableModel;
public class Controller_ERP_Two {

	AWebServiceForContentAndMetadataFromCRONUSSoapProxy proxy = new AWebServiceForContentAndMetadataFromCRONUSSoapProxy(); 
	
	
	 public DefaultTableModel DisplayEmployee () {
		 DefaultTableModel model = new DefaultTableModel();
		 try {
			if(proxy.displayEmployee().length > 0) {
				model.addColumn("No_"); 
				model.addColumn("First Name"); 
				model.addColumn("Last Name"); 
				model.addColumn("Job Title"); 
				model.addColumn("City"); 
				
				for(Employee e : proxy.displayEmployee()) {
					model.addRow(new String[] {e.getNo_(), e.getFirstName(), e.getLastName(), e.getJobTitle(), e.getAddress(), e.getCity()});					
				}
			 }
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return model; 
	 }
	 
	 public DefaultTableModel DisplayMetadata (String tableName) {
		 DefaultTableModel model = new DefaultTableModel();
		 try {
			if(proxy.displayMetadataFromTable(tableName).length > 0) {
				model.addColumn("COLUMN_NAME"); 
				model.addColumn("ORDINAL_POSITION"); 
				model.addColumn("IS_NULLABLE"); 
				model.addColumn("DATA_TYPE"); 
				model.addColumn("CHARACTER_MAXIMUM_LENGTH"); 
				
				for(MetadataModell m : proxy.displayMetadataFromTable(tableName)) {
					model.addRow(new String[] {m.getColumn_name(), Integer.toString(m.getOrdinal_position()), m.getIs_nullable(),
							m.getData_type(), Integer.toString(m.getCharacter_maximum_length())});					
				}
			 }
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return model; 
	 }

	 
	 public DefaultTableModel DisplayEmployeeAbsence () {
		 DefaultTableModel model = new DefaultTableModel();
		 try {
			if(proxy.displayEmployeeAbsence().length > 0) {
				model.addColumn("Entry No_"); 
				model.addColumn("Employee No_"); 
				model.addColumn("From Date"); 
				model.addColumn("Cause of Absence Code"); 
				DateFormat dF = new SimpleDateFormat("yyyy-MM-dd");
				for(EmployeeAbsence e : proxy.displayEmployeeAbsence()) {
					model.addRow(new String[] {Integer.toString(e.getEntryNo_()), e.getEmployeeNo_(),dF.format(e.getFromDate().getTime()), e.getCauseOfAbsenceCode()});					
				}
			 }
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return model; 
	 }

	 
	 public DefaultTableModel DisplayEmployeeQualification () {
		 DefaultTableModel model = new DefaultTableModel();
		 try {
			if(proxy.displayEmployeeQualification().length > 0) {
				model.addColumn("Employee No_"); 
				model.addColumn("Line No_"); 
				model.addColumn("Qualificaton Code"); 
				model.addColumn("Description"); 				
				for(EmployeeQualification e : proxy.displayEmployeeQualification()) {
					model.addRow(new String[]{e.getEmployeeNo_(), Integer.toString(e.getLineNo_()), e.getQualificationCode(), e.getDescription()});
				}
			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return model;
	}
	 
	 public DefaultTableModel DisplayEmployeeStatisticsGroup () {
		 DefaultTableModel model = new DefaultTableModel();
		 try {
			if(proxy.displayEmployeeStatisticsGroup().length > 0) {
				model.addColumn("Code"); 
				model.addColumn("Description"); 
				
				for(EmployeeStatisticsGroup e : proxy.displayEmployeeStatisticsGroup()) {
					model.addRow(new String[] {e.getCode(), e.getDescription()});					
				}
			 }
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return model; 
	 }

	 public DefaultTableModel DisplayEmploymentContract () {
		 DefaultTableModel model = new DefaultTableModel();
		 try {
			if(proxy.displayEmploymentContract().length > 0) {
				model.addColumn("Code"); 
				model.addColumn("Description"); 				
				for(EmploymentContract e : proxy.displayEmploymentContract()) {
					model.addRow(new String[] {e.getCode(), e.getDescription()});					
				}
			 }
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return model; 
	 }
	 
	 public DefaultTableModel DisplayEmployeeAndRelative() {
		 DefaultTableModel model = new DefaultTableModel();
		 try {
			if(proxy.displayEmployeesAndRelatives().length > 0) {
				model.addColumn("Employee No_"); 
				model.addColumn("Line No_"); 
				model.addColumn("Relative Code"); 
				model.addColumn("First Name"); 
				model.addColumn("Last Name"); 				
				for(EmployeeAndRelative e : proxy.displayEmployeesAndRelatives()) {
					model.addRow(new String[] {e.getEmployeeNo_(), Integer.toString(e.getLineNo_()), e.getRelativeCode(), e.getFirstName(), e.getLastName()});					
				}
			 }
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return model; 
	 }
	 
	 //--------------------------------------------------------------------------------------------------------------------------------------------------------

	 public DefaultTableModel DisplayEmployeesSickDuring2004() {
		 DefaultTableModel model = new DefaultTableModel();
		 try {
			if(proxy.displayEmployeesSickDuring2004().length > 0) {
				model.addColumn("No_"); 
				model.addColumn("First Name"); 
				model.addColumn("Last Name"); 
				model.addColumn("job Title"); 
				model.addColumn("Address"); 			
				model.addColumn("City"); 				
				for(Employee e : proxy.displayEmployeesSickDuring2004()) {
					model.addRow(new String[] {e.getNo_(), e.getFirstName(), e.getLastName(), e.getJobTitle(), e.getAddress(), e.getCity()});					
				}
			 }
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return model; 
	 }


	 public DefaultTableModel DisplayEmployeeMostAbsentDuring2004() {
		 DefaultTableModel model = new DefaultTableModel();
		 try {
			if(proxy.displayEmployeeMostAbsentDuring2004().length > 0) {

				model.addColumn("First Name"); 
				for(Employee e : proxy.displayEmployeeMostAbsentDuring2004()) {
					model.addRow(new String[] {e.getFirstName()});
					}
			 }
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return model; 
	 }

	
	 public DefaultTableModel DisplayAllKeys() {
		 DefaultTableModel model = new DefaultTableModel();
		 try {
			if(proxy.displayAllKeys().length > 0) {
				model.addColumn("name"); 
				model.addColumn("id"); 
				model.addColumn("xtype"); 				
				for(Key k: proxy.displayAllKeys()) {
					model.addRow(new String[] {k.getName(), Integer.toString(k.getID()), k.getXtype()});					
				}
			 }
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return model; 
	 }

	  
	 public DefaultTableModel DisplayAllConstraints() {
		 DefaultTableModel model = new DefaultTableModel();
		 try {
			if(proxy.displayAllConstraints().length > 0) {
				model.addColumn("CONSTRAINT_NAME"); 
				model.addColumn("CONSTRAINT_TYPE"); 			
				for(Constraint c : proxy.displayAllConstraints()) {
					model.addRow(new String[] {c.getConstraint_name(), c.getConstraint_type()});					
				}
			 }
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return model; 
	 }

	 
	 public DefaultTableModel DisplayAllTablesViaINFORMATION_SCHEMA() {
		 DefaultTableModel model = new DefaultTableModel();
		 try {
			if(proxy.displayAllTablesViaINFORMTION_SCHEMA().length > 0) {
				model.addColumn("TABLE_NAME"); 
				model.addColumn("TABLE_TYPE"); 				
				for(Table t : proxy.displayAllTablesViaINFORMTION_SCHEMA()) {
					model.addRow(new String[] {t.getNameT(), t.getTypeT()});					
				}
			 }
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return model; 
	 }

	 public DefaultTableModel DisplayAllTablesViaSYSOBJECT() {
		 DefaultTableModel model = new DefaultTableModel();
		 try {
			if(proxy.displayAllTablesViaSYSOBJECT().length > 0) {
				model.addColumn("name"); 
				model.addColumn("xtype"); 				
				for(Table t : proxy.displayAllTablesViaSYSOBJECT()) {
					model.addRow(new String[] {t.getNameT(), t.getTypeT()});					
				}
			 }
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return model; 
	 }

	 public DefaultTableModel DisplayAllColumsViaINFORMATION_SCHEMA() {
		 DefaultTableModel model = new DefaultTableModel();
		 try {
			if(proxy.displayAllColumsViaINFORMATION_SCHEMA().length > 0) {
				model.addColumn("TABLE_NAME"); 			
				for(Colum c : proxy.displayAllColumsViaINFORMATION_SCHEMA()) {
					model.addRow(new String[] {c.getNameT()}); 
				}
			 }
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return model; 
	 }

	 
	 public DefaultTableModel DisplayAllColumsViaSYS() {
		 DefaultTableModel model = new DefaultTableModel();
		 try {
			if(proxy.displayALLColumsViaSYS().length > 0) {
				model.addColumn("name"); 				
				for(Colum c : proxy.displayALLColumsViaSYS()) {
					model.addRow(new String[] {c.getNameT()});					
				}
			 }
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return model; 
	 }

	 
	 public DefaultTableModel DisplayAllIndexes() {
		 DefaultTableModel model = new DefaultTableModel();
		 try {
			if(proxy.displayAllIndexes().length > 0) {
				model.addColumn("object_id"); 
				model.addColumn("name"); 
				model.addColumn("index_id"); 
				model.addColumn("type_desc");  				
				for(Index i : proxy.displayAllIndexes()) {
					model.addRow(new String[] {Integer.toString(i.getObject_id()), i.getName(), Integer.toString(i.getIndex_id()), i.getTyp_desc()});					
				}
			 }
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return model; 
	 }


}
