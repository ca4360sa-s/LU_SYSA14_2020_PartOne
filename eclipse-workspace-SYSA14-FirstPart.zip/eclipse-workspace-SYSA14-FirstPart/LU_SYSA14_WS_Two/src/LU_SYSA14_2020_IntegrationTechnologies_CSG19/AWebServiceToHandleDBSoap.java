/**
 * AWebServiceToHandleDBSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

public interface AWebServiceToHandleDBSoap extends java.rmi.Remote {
    public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Product[] displayAllProducts() throws java.rmi.RemoteException;
}
