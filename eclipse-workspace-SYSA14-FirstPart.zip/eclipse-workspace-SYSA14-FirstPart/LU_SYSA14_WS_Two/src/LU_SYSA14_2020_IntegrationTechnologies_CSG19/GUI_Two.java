package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JScrollPane;

public class GUI_Two {

	private JFrame frameWSTwo;
	private JTable tableDisplayAllProducts;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI_Two window = new GUI_Two();
					window.frameWSTwo.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUI_Two() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frameWSTwo = new JFrame();
		frameWSTwo.setTitle("Web Service Uppgift 2");
		frameWSTwo.setBounds(100, 100, 700, 600);
		frameWSTwo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		AWebServiceToHandleDBSoapProxy proxy = new AWebServiceToHandleDBSoapProxy();
		frameWSTwo.getContentPane().setLayout(null);
		
		JLabel lblHeadInfo = new JLabel("Visningsalternativ f\u00F6r produkter - Klient 3");
		lblHeadInfo.setBounds(160, 32, 380, 39);
		lblHeadInfo.setFont(new Font("Tahoma", Font.BOLD, 16));
		frameWSTwo.getContentPane().add(lblHeadInfo);
		
		JLabel lblDisplayProductNF = new JLabel("Feedback");
		lblDisplayProductNF.setBounds(49, 134, 228, 19);
		lblDisplayProductNF.setForeground(new Color(255, 51, 51));
		frameWSTwo.getContentPane().add(lblDisplayProductNF);
		lblDisplayProductNF.setVisible(false);
		
		JLabel lblDisplayProductsPF = new JLabel("Feedback");
		lblDisplayProductsPF.setBounds(49, 134, 228, 19);
		lblDisplayProductsPF.setForeground(new Color(0, 153, 0));
		frameWSTwo.getContentPane().add(lblDisplayProductsPF);
		lblDisplayProductsPF.setVisible(false); 		
		
		JButton btnDisplayAllProducts = new JButton("Visa alla");
		btnDisplayAllProducts.setBounds(49, 155, 100, 30);
		btnDisplayAllProducts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Product[] products = proxy.displayAllProducts();
					if(products.length == 0) {
						lblDisplayProductNF.setText("Finns inga produkter att visa");
						lblDisplayProductNF.setVisible(true);
					}
					else {
						DefaultTableModel model = new DefaultTableModel(); 
						model.addColumn("ProduktID");
						model.addColumn("Produktnamn");
						model.addColumn("Beskrivning");
						model.addColumn("Lagerkvantitet");		
						for (Product p : products) {
							model.addRow(new Object [] {p.getProductID(), p.getProductName(), p.getProductDiscription(), p.getStockQuantity()});
						}
						tableDisplayAllProducts.setModel(model);
						lblDisplayProductsPF.setText("Alla "+ model.getRowCount()+" st produkter visas");
						lblDisplayProductsPF.setVisible(true);
					}
				} catch (RemoteException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 				
			}
		});
		frameWSTwo.getContentPane().add(btnDisplayAllProducts);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(241, 149, 409, 377);
		frameWSTwo.getContentPane().add(scrollPane);
		
		tableDisplayAllProducts = new JTable();
		scrollPane.setViewportView(tableDisplayAllProducts);
		

		
		
	}
}
