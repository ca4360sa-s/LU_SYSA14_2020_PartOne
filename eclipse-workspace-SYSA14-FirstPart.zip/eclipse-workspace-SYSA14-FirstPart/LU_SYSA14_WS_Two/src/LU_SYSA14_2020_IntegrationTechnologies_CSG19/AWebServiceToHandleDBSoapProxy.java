package LU_SYSA14_2020_IntegrationTechnologies_CSG19;

public class AWebServiceToHandleDBSoapProxy implements LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleDBSoap {
  private String _endpoint = null;
  private LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleDBSoap aWebServiceToHandleDBSoap = null;
  
  public AWebServiceToHandleDBSoapProxy() {
    _initAWebServiceToHandleDBSoapProxy();
  }
  
  public AWebServiceToHandleDBSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initAWebServiceToHandleDBSoapProxy();
  }
  
  private void _initAWebServiceToHandleDBSoapProxy() {
    try {
      aWebServiceToHandleDBSoap = (new LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleDBLocator()).getAWebServiceToHandleDBSoap();
      if (aWebServiceToHandleDBSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)aWebServiceToHandleDBSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)aWebServiceToHandleDBSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (aWebServiceToHandleDBSoap != null)
      ((javax.xml.rpc.Stub)aWebServiceToHandleDBSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.AWebServiceToHandleDBSoap getAWebServiceToHandleDBSoap() {
    if (aWebServiceToHandleDBSoap == null)
      _initAWebServiceToHandleDBSoapProxy();
    return aWebServiceToHandleDBSoap;
  }
  
  public LU_SYSA14_2020_IntegrationTechnologies_CSG19.Product[] displayAllProducts() throws java.rmi.RemoteException{
    if (aWebServiceToHandleDBSoap == null)
      _initAWebServiceToHandleDBSoapProxy();
    return aWebServiceToHandleDBSoap.displayAllProducts();
  }
  
  
}